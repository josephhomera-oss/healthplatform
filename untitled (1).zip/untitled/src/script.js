// script.js - advanced version with all new features

(function() {
    "use strict";

    const GEMINI_API_KEY = 'AIzaSyAWN9yR54iK20W3CAZOkcXUedGh-6jiGuE';
    const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

    // ---------- DOM elements ----------
    const flRoundSpan = document.getElementById('flRoundDisplay');
    const clientCountSpan = document.getElementById('clientCount');
    const xaiToggle = document.getElementById('xaiToggle');
    const heatmapOverlay = document.getElementById('heatmapOverlay');
    const analyzeRadBtn = document.getElementById('analyzeRadiologyBtn');
    const radiologyResult = document.getElementById('radiologyResult');
    const radSpinner = document.getElementById('radSpinner');
    const explainRadBtn = document.getElementById('explainRadBtn');
    const simulateUsBtn = document.getElementById('simulateUsBtn');
    const usResult = document.getElementById('usResult');
    const usSpinner = document.getElementById('usSpinner');
    const explainUsBtn = document.getElementById('explainUsBtn');
    const generateCausalBtn = document.getElementById('generateCausalBtn');
    const causalResult = document.getElementById('causalResult');
    const causalSpinner = document.getElementById('causalSpinner');
    const explainCausalBtn = document.getElementById('explainCausalBtn');
    const guidanceArrow = document.getElementById('guidanceArrow');
    const guidanceMessage = document.getElementById('guidanceMessage');
    const usConfidenceSpan = document.getElementById('usConfidence');
    const chatMessages = document.getElementById('chatMessages');
    const chatInput = document.getElementById('chatInput');
    const sendChatBtn = document.getElementById('sendChatBtn');
    const chatStatus = document.getElementById('chatStatus');
    const diceInternal = document.getElementById('diceInternal');
    const diceExternal = document.getElementById('diceExternal');
    const simulateShiftBtn = document.getElementById('simulateShiftBtn');
    const shiftStatus = document.getElementById('shiftStatus');
    const phiToggle = document.getElementById('phiToggle');
    const radPhiStatus = document.getElementById('radPhiStatus');
    const showShapBtn = document.getElementById('showShapBtn');
    const shapSim = document.getElementById('shapSim');
    const chips = document.querySelectorAll('.chip');

    // ---------- state ----------
    let flRound = 49;
    let clientCount = 5;
    let radIntDice = 0.94;
    let radExtDice = 0.89;

    // ---------- helpers ----------
    function updateFederated() {
        if (flRoundSpan) flRoundSpan.textContent = flRound;
        if (clientCountSpan) clientCountSpan.textContent = clientCount;
    }

    async function callGemini(prompt, signal) {
        const response = await fetch(GEMINI_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: { temperature: 0.2, maxOutputTokens: 300 }
            }),
            signal: signal
        });
        if (!response.ok) {
            const err = await response.text();
            throw new Error(`Gemini error ${response.status}: ${err}`);
        }
        const data = await response.json();
        const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!text) throw new Error('Empty Gemini response');
        return text;
    }

    function addChatMessage(text, isUser = false) {
        const div = document.createElement('div');
        div.className = isUser ? 'message user' : 'message assistant';
        div.innerHTML = `<span>${text}</span>`;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // ---------- radiology ----------
    if (analyzeRadBtn) {
        analyzeRadBtn.addEventListener('click', async () => {
            radiologyResult.innerText = '';
            radSpinner.style.display = 'inline-block';
            analyzeRadBtn.disabled = true;
            try {
                const prompt = `You are a radiologist. Generate a short structured report for a chest CT with an 8mm solid nodule in left upper lobe. Include impression and follow-up. Use clinical language.`;
                const answer = await callGemini(prompt, new AbortController().signal);
                radiologyResult.innerText = answer.slice(0, 280) + (answer.length > 280 ? '…' : '');
                flRound += 1;
                clientCount = 5 + Math.floor(Math.random() * 3);
                updateFederated();
            } catch (e) {
                radiologyResult.innerText = '⚠️ ' + e.message;
            } finally {
                radSpinner.style.display = 'none';
                analyzeRadBtn.disabled = false;
            }
        });
    }

    if (explainRadBtn) {
        explainRadBtn.addEventListener('click', async () => {
            addChatMessage('Explain the radiology finding: 8mm solid nodule LUL', true);
            chatStatus.innerText = 'Gemini is thinking...';
            try {
                const prompt = `Explain in simple terms what an 8mm solid lung nodule means, possible differentials, and next steps for a patient.`;
                const answer = await callGemini(prompt, new AbortController().signal);
                addChatMessage(answer);
            } catch (e) {
                addChatMessage('⚠️ ' + e.message);
            } finally {
                chatStatus.innerText = '';
            }
        });
    }

    // ---------- ultrasound ----------
    if (simulateUsBtn) {
        simulateUsBtn.addEventListener('click', async () => {
            usResult.innerText = '';
            usSpinner.style.display = 'inline-block';
            simulateUsBtn.disabled = true;
            try {
                const prompt = `You are an expert sonographer. Provide 3 short sequential commands to obtain an apical four-chamber view on an adult. Be concise.`;
                const answer = await callGemini(prompt, new AbortController().signal);
                usResult.innerText = answer.slice(0, 150);
                const confidence = (0.75 + Math.random() * 0.2).toFixed(2);
                usConfidenceSpan.textContent = confidence;
                guidanceMessage.innerText = answer.split('.')[0] + '.';
                if (guidanceArrow) {
                    guidanceArrow.style.transform = `rotate(${Math.random() * 30 - 15}deg)`;
                }
            } catch (e) {
                usResult.innerText = '⚠️ ' + e.message;
            } finally {
                usSpinner.style.display = 'none';
                simulateUsBtn.disabled = false;
            }
        });
    }

    if (explainUsBtn) {
        explainUsBtn.addEventListener('click', async () => {
            addChatMessage('Why is my ultrasound image quality low?', true);
            chatStatus.innerText = 'Gemini is thinking...';
            try {
                const prompt = `List 3 common reasons for poor image quality in cardiac ultrasound and how to fix them.`;
                const answer = await callGemini(prompt, new AbortController().signal);
                addChatMessage(answer);
            } catch (e) {
                addChatMessage('⚠️ ' + e.message);
            } finally {
                chatStatus.innerText = '';
            }
        });
    }

    // ---------- causal ----------
    if (generateCausalBtn) {
        generateCausalBtn.addEventListener('click', async () => {
            causalResult.innerText = '';
            causalSpinner.style.display = 'inline-block';
            generateCausalBtn.disabled = true;
            try {
                const prompt = `Explain Individual Treatment Effect (ITE) using an oncology example with two treatments. Keep it brief for clinicians.`;
                const answer = await callGemini(prompt, new AbortController().signal);
                causalResult.innerText = answer.slice(0, 280) + (answer.length > 280 ? '…' : '');
                const newIte = (0.2 + Math.random() * 0.15).toFixed(2);
                const iteSpan = document.querySelector('.ite-value');
                if (iteSpan) iteSpan.textContent = newIte;
            } catch (e) {
                causalResult.innerText = '⚠️ ' + e.message;
            } finally {
                causalSpinner.style.display = 'none';
                generateCausalBtn.disabled = false;
            }
        });
    }

    if (explainCausalBtn) {
        explainCausalBtn.addEventListener('click', async () => {
            addChatMessage('Explain the causal graph for lung cancer treatment response', true);
            chatStatus.innerText = 'Gemini is thinking...';
            try {
                const prompt = `Describe a simple Structural Causal Model (SCM) for predicting tumor response to immunotherapy. Include nodes: tumor volume, PD-L1, treatment.`;
                const answer = await callGemini(prompt, new AbortController().signal);
                addChatMessage(answer);
            } catch (e) {
                addChatMessage('⚠️ ' + e.message);
            } finally {
                chatStatus.innerText = '';
            }
        });
    }

    // ---------- XAI toggle ----------
    if (xaiToggle && heatmapOverlay) {
        xaiToggle.addEventListener('change', (e) => {
            heatmapOverlay.style.opacity = e.target.checked ? '0.45' : '0';
        });
    }

    // ---------- domain shift simulator ----------
    if (simulateShiftBtn) {
        simulateShiftBtn.addEventListener('click', () => {
            // degrade external dice
            radExtDice = Math.max(0.6, (radExtDice - 0.05).toFixed(2));
            if (diceExternal) diceExternal.textContent = radExtDice;
            const drop = ((radIntDice - radExtDice) / radIntDice * 100).toFixed(1);
            if (shiftStatus) shiftStatus.innerText = `avg drop ${drop}%`;
            // update bars
            const bars = document.querySelectorAll('.shift-metrics .bar');
            if (bars.length >= 3) {
                bars[1].style.width = '73%'; bars[1].innerText = '0.73';
                bars[2].style.width = '69%'; bars[2].innerText = '0.69';
            }
        });
    }

    // ---------- PHI toggle ----------
    if (phiToggle && radPhiStatus) {
        phiToggle.addEventListener('change', (e) => {
            radPhiStatus.innerText = e.target.checked ? 'PHI removed' : 'PHI present (simulated)';
            radPhiStatus.style.backgroundColor = e.target.checked ? '#d4edda' : '#f8d7da';
        });
    }

    // ---------- SHAP mock ----------
    if (showShapBtn && shapSim) {
        showShapBtn.addEventListener('click', () => {
            shapSim.style.display = shapSim.style.display === 'none' ? 'flex' : 'none';
        });
    }

    // ---------- chat ----------
    async function sendChatMessage() {
        const text = chatInput.value.trim();
        if (!text) return;
        addChatMessage(text, true);
        chatInput.value = '';
        chatStatus.innerText = 'Gemini is thinking...';
        try {
            const prompt = `You are an AI assistant specialized in medical imaging, federated learning, and causal inference. Answer concisely: ${text}`;
            const answer = await callGemini(prompt, new AbortController().signal);
            addChatMessage(answer);
        } catch (e) {
            addChatMessage('⚠️ ' + e.message);
        } finally {
            chatStatus.innerText = '';
        }
    }

    if (sendChatBtn) {
        sendChatBtn.addEventListener('click', sendChatMessage);
        chatInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') sendChatMessage();
        });
    }

    // suggested chips
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            const prompt = chip.getAttribute('data-prompt');
            if (prompt) {
                chatInput.value = prompt;
                sendChatMessage();
            }
        });
    });

    // ---------- initial updates ----------
    updateFederated();
    if (radPhiStatus) radPhiStatus.innerText = 'PHI removed';
})();