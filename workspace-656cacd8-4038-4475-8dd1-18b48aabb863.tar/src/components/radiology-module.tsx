'use client';

import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  Upload,
  FileImage,
  AlertCircle,
  CheckCircle2,
  Loader2,
  ChevronDown,
  ChevronUp,
  Brain,
  Target,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

interface Patient {
  id: string;
  medicalRecordNumber: string;
  fullName: string;
  dateOfBirth: string;
  gender: string;
}

interface Scan {
  id: string;
  patient: { name: string; mrn: string };
  scanType: string;
  bodyPart: string;
  modalityDetails: string;
  status: string;
  diagnosis?: string;
  confidence?: number;
  createdAt: string;
}

interface AnalysisResult {
  id: string;
  diagnosis: string;
  confidence: number;
  findings: Array<{
    type: string;
    location: string;
    severity: string;
    description: string;
  }>;
  nodules: Array<{
    id: string;
    size: number;
    location: string;
    characteristics: string;
    malignancyRisk: number;
  }>;
  recommendations: string[];
  processingTimeMs: number;
}

export function RadiologyModule() {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedScan, setSelectedScan] = useState<Scan | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeTab, setActiveTab] = useState('upload');

  const queryClient = useQueryClient();

  // Fetch patients
  const { data: patientsData } = useQuery({
    queryKey: ['patients'],
    queryFn: async () => {
      const response = await fetch('/api/patients?limit=50');
      return response.json();
    },
  });

  // Fetch scans
  const { data: scansData } = useQuery({
    queryKey: ['scans', 'CT'],
    queryFn: async () => {
      const response = await fetch('/api/scans?scanType=CT&limit=20');
      return response.json();
    },
  });

  // Analyze scan mutation
  const analyzeMutation = useMutation({
    mutationFn: async (scanId: string) => {
      const response = await fetch('/api/radiology/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scanId }),
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setAnalysisResult(data.result);
        setIsAnalyzing(false);
        setActiveTab('results');
        queryClient.invalidateQueries({ queryKey: ['scans'] });
      }
    },
  });

  const handleAnalyze = useCallback(() => {
    if (selectedScan) {
      setIsAnalyzing(true);
      analyzeMutation.mutate(selectedScan.id);
    }
  }, [selectedScan, analyzeMutation]);

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'moderate':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300';
      case 'benign':
        return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'severe':
        return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-slate-100 text-slate-700 dark:bg-slate-900 dark:text-slate-300';
    }
  };

  const getRiskColor = (risk: number) => {
    if (risk >= 0.7) return 'text-red-600';
    if (risk >= 0.4) return 'text-amber-600';
    return 'text-green-600';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Activity className="w-7 h-7 text-blue-500" />
            Radiology AI Analysis
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Federated foundation model for CT scan analysis with XAI explanations
          </p>
        </div>
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          Model v2.1.0-federated
        </Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 max-w-md">
          <TabsTrigger value="upload">Upload & Select</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        {/* Upload & Select Tab */}
        <TabsContent value="upload" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Patient Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Select Patient</CardTitle>
                <CardDescription>Choose a patient for CT scan analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {patientsData?.patients?.map((patient: Patient) => (
                      <button
                        key={patient.id}
                        onClick={() => setSelectedPatient(patient)}
                        className={`w-full p-3 rounded-lg text-left transition-colors ${
                          selectedPatient?.id === patient.id
                            ? 'bg-blue-50 dark:bg-blue-900/30 border-2 border-blue-500'
                            : 'bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-slate-800 dark:text-white">
                              {patient.fullName}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400">
                              MRN: {patient.medicalRecordNumber}
                            </p>
                          </div>
                          <Badge variant="outline">{patient.gender}</Badge>
                        </div>
                      </button>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Scan Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Available CT Scans</CardTitle>
                <CardDescription>Select a scan to analyze</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {scansData?.scans?.map((scan: Scan) => (
                      <button
                        key={scan.id}
                        onClick={() => setSelectedScan(scan)}
                        className={`w-full p-3 rounded-lg text-left transition-colors ${
                          selectedScan?.id === scan.id
                            ? 'bg-blue-50 dark:bg-blue-900/30 border-2 border-blue-500'
                            : 'bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-slate-800 dark:text-white">
                              {scan.bodyPart} - {scan.scanType}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400">
                              Patient: {scan.patient.name}
                            </p>
                          </div>
                          <div className="text-right">
                            <Badge className={`${
                              scan.status === 'COMPLETED' ? 'bg-green-100 text-green-700' :
                              scan.status === 'PROCESSING' ? 'bg-blue-100 text-blue-700' :
                              'bg-yellow-100 text-yellow-700'
                            }`}>
                              {scan.status}
                            </Badge>
                            {scan.confidence && (
                              <p className="text-xs text-slate-500 mt-1">
                                {Math.round(scan.confidence * 100)}% conf
                              </p>
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Upload Area */}
          <Card className="border-dashed">
            <CardContent className="p-8">
              <div className="flex flex-col items-center justify-center text-center">
                <Upload className="w-12 h-12 text-slate-400 mb-4" />
                <h3 className="font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Upload New CT Scan
                </h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  Drag and drop DICOM files or click to browse
                </p>
                <Button variant="outline">
                  <FileImage className="w-4 h-4 mr-2" />
                  Select Files
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analysis Tab */}
        <TabsContent value="analysis" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Selected Scan Info */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Scan Details</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedScan ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-slate-500">Patient</p>
                        <p className="font-medium">{selectedScan.patient.name}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500">MRN</p>
                        <p className="font-medium">{selectedScan.patient.mrn}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500">Scan Type</p>
                        <p className="font-medium">{selectedScan.scanType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-500">Body Part</p>
                        <p className="font-medium">{selectedScan.bodyPart}</p>
                      </div>
                    </div>

                    <Separator />

                    {/* Simulated CT Viewer */}
                    <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 opacity-20">
                        {/* Simulated medical imaging pattern */}
                        <div className="w-full h-full" style={{
                          backgroundImage: 'radial-gradient(circle, rgba(100,150,200,0.3) 1px, transparent 1px)',
                          backgroundSize: '20px 20px'
                        }}></div>
                      </div>
                      <div className="text-center z-10">
                        <FileImage className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                        <p className="text-slate-400">CT Scan Preview</p>
                        <p className="text-xs text-slate-500 mt-1">
                          {selectedScan.modalityDetails || 'CT Scan'}
                        </p>
                      </div>
                      {/* Crosshair overlay */}
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="w-px h-full bg-red-500/30"></div>
                        <div className="absolute w-full h-px bg-red-500/30"></div>
                      </div>
                    </div>

                    <Button
                      onClick={handleAnalyze}
                      disabled={isAnalyzing}
                      className="w-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600"
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Brain className="w-4 h-4 mr-2" />
                          Run AI Analysis
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">Select a scan to analyze</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Analysis Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Analysis Pipeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: 'Image Preprocessing', status: isAnalyzing ? 'processing' : 'pending' },
                    { name: 'Nodule Detection', status: 'pending' },
                    { name: 'Classification', status: 'pending' },
                    { name: 'XAI Generation', status: 'pending' },
                    { name: 'Report Generation', status: 'pending' },
                  ].map((step, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        step.status === 'completed' ? 'bg-green-100' :
                        step.status === 'processing' ? 'bg-blue-100' :
                        'bg-slate-100 dark:bg-slate-800'
                      }`}>
                        {step.status === 'completed' ? (
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                        ) : step.status === 'processing' ? (
                          <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                        ) : (
                          <span className="text-xs text-slate-400">{index + 1}</span>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                          {step.name}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="results" className="space-y-6">
          {analysisResult ? (
            <>
              {/* Primary Diagnosis */}
              <Card className="border-2 border-blue-500">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500 mb-1">Primary Diagnosis</p>
                      <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
                        {analysisResult.diagnosis}
                      </h2>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-slate-500 mb-1">Confidence Score</p>
                      <p className="text-3xl font-bold text-blue-600">
                        {Math.round(analysisResult.confidence * 100)}%
                      </p>
                    </div>
                  </div>
                  <Progress value={analysisResult.confidence * 100} className="mt-4 h-2" />
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Findings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Findings</CardTitle>
                    <CardDescription>Detailed analysis results</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysisResult.findings.map((finding, index) => (
                        <div
                          key={index}
                          className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-slate-800 dark:text-white">
                              {finding.type}
                            </span>
                            <Badge className={getSeverityColor(finding.severity)}>
                              {finding.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-slate-600 dark:text-slate-300">
                            <strong>Location:</strong> {finding.location}
                          </p>
                          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                            {finding.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Nodule Details */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Target className="w-5 h-5 text-red-500" />
                      Nodule Analysis
                    </CardTitle>
                    <CardDescription>
                      {analysisResult.nodules.length} nodule(s) detected
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysisResult.nodules.map((nodule) => (
                        <div
                          key={nodule.id}
                          className="p-3 rounded-lg border border-slate-200 dark:border-slate-700"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">Nodule {nodule.id}</span>
                            <span className={`text-sm font-medium ${getRiskColor(nodule.malignancyRisk)}`}>
                              Risk: {Math.round(nodule.malignancyRisk * 100)}%
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <span className="text-slate-500">Size:</span>{' '}
                              <span className="font-medium">{nodule.size}mm</span>
                            </div>
                            <div>
                              <span className="text-slate-500">Location:</span>{' '}
                              <span className="font-medium">{nodule.location}</span>
                            </div>
                          </div>
                          <p className="text-xs text-slate-500 mt-2">
                            {nodule.characteristics}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* XAI Visualization */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-500" />
                    Explainable AI (XAI) - Grad-CAM Visualization
                  </CardTitle>
                  <CardDescription>
                    AI attention heatmap showing regions of interest
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-gradient-to-br from-purple-900 via-blue-900 to-teal-900 rounded-lg relative overflow-hidden">
                    {/* Simulated heatmap overlay */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="relative">
                        <div className="w-64 h-64 rounded-full bg-gradient-radial from-red-500/60 via-yellow-500/40 to-transparent blur-xl"></div>
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <Target className="w-12 h-12 text-white/80" />
                        </div>
                      </div>
                    </div>
                    <div className="absolute bottom-4 right-4 bg-black/50 rounded-lg p-2">
                      <div className="flex items-center gap-2 text-xs text-white">
                        <div className="w-16 h-2 rounded bg-gradient-to-r from-blue-500 via-yellow-500 to-red-500"></div>
                        <span>Attention Intensity</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Clinical Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {analysisResult.recommendations.map((rec, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 rounded bg-slate-50 dark:bg-slate-800">
                        <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5" />
                        <span className="text-sm text-slate-700 dark:text-slate-300">{rec}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Processing Stats */}
              <div className="flex items-center justify-between text-sm text-slate-500">
                <span>Processing Time: {(analysisResult.processingTimeMs / 1000).toFixed(2)}s</span>
                <span>Model Version: v2.1.0-federated</span>
              </div>
            </>
          ) : (
            <Card>
              <CardContent className="p-12">
                <div className="text-center">
                  <AlertCircle className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-600 dark:text-slate-400">
                    No Analysis Results
                  </h3>
                  <p className="text-slate-500 dark:text-slate-500 mt-2">
                    Run an analysis to see results here
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
