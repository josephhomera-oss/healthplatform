'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Settings,
  Users,
  Shield,
  Database,
  Activity,
  Plus,
  Edit,
  Trash2,
  Key,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  hospitalAffiliation: string | null;
  isActive: boolean;
  lastLoginAt: string | null;
  scanCount: number;
  reportCount: number;
  createdAt: string;
}

export function AdminModule() {
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false);
  const [newUser, setNewUser] = useState({
    email: '',
    name: '',
    role: 'RADIOLOGIST',
    password: '',
    hospitalAffiliation: '',
  });

  const queryClient = useQueryClient();

  // Fetch users
  const { data: usersData, isLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: async () => {
      const response = await fetch('/api/admin/users');
      return response.json();
    },
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (userData: typeof newUser) => {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
      setIsCreateUserOpen(false);
      setNewUser({
        email: '',
        name: '',
        role: 'RADIOLOGIST',
        password: '',
        hospitalAffiliation: '',
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch('/api/admin/users', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: userId }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
  });

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      case 'RADIOLOGIST':
        return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'SONOGRAPHER':
        return 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300';
      case 'RESEARCHER':
        return 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300';
      default:
        return 'bg-slate-100 text-slate-700 dark:bg-slate-900 dark:text-slate-300';
    }
  };

  if (isLoading || !usersData) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
        </div>
      </div>
    );
  }

  const users: User[] = usersData.users || [];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Settings className="w-7 h-7 text-slate-500" />
            Admin Panel
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            System administration and user management
          </p>
        </div>
        <Badge variant="outline" className="bg-slate-50 text-slate-700 border-slate-200">
          <Shield className="w-3 h-3 mr-1" />
          Admin Access
        </Badge>
      </div>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="w-4 h-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="system">
            <Database className="w-4 h-4 mr-2" />
            System
          </TabsTrigger>
          <TabsTrigger value="audit">
            <Activity className="w-4 h-4 mr-2" />
            Audit Log
          </TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">User Management</CardTitle>
                  <CardDescription>Manage system users and permissions</CardDescription>
                </div>
                <Dialog open={isCreateUserOpen} onOpenChange={setIsCreateUserOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add User
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create New User</DialogTitle>
                      <DialogDescription>
                        Add a new user to the Healthcare AI system
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={newUser.name}
                          onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                          placeholder="Dr. John Smith"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={newUser.email}
                          onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                          placeholder="john.smith@hospital.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">Password</Label>
                        <Input
                          id="password"
                          type="password"
                          value={newUser.password}
                          onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                          placeholder="••••••••"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="role">Role</Label>
                        <Select
                          value={newUser.role}
                          onValueChange={(value) => setNewUser({ ...newUser, role: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ADMIN">Administrator</SelectItem>
                            <SelectItem value="RADIOLOGIST">Radiologist</SelectItem>
                            <SelectItem value="SONOGRAPHER">Sonographer</SelectItem>
                            <SelectItem value="RESEARCHER">Researcher</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="hospital">Hospital Affiliation</Label>
                        <Input
                          id="hospital"
                          value={newUser.hospitalAffiliation}
                          onChange={(e) => setNewUser({ ...newUser, hospitalAffiliation: e.target.value })}
                          placeholder="Medical Center Hospital"
                        />
                      </div>
                      <Button
                        onClick={() => createUserMutation.mutate(newUser)}
                        className="w-full"
                        disabled={!newUser.email || !newUser.name || !newUser.password}
                      >
                        Create User
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700">
                      <th className="text-left py-3 text-sm font-medium text-slate-500">User</th>
                      <th className="text-left py-3 text-sm font-medium text-slate-500">Role</th>
                      <th className="text-left py-3 text-sm font-medium text-slate-500">Hospital</th>
                      <th className="text-left py-3 text-sm font-medium text-slate-500">Status</th>
                      <th className="text-left py-3 text-sm font-medium text-slate-500">Activity</th>
                      <th className="text-right py-3 text-sm font-medium text-slate-500">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id} className="border-b border-slate-100 dark:border-slate-800">
                        <td className="py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-medium text-sm">
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div>
                              <p className="font-medium text-slate-800 dark:text-white">
                                {user.name}
                              </p>
                              <p className="text-xs text-slate-500">{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4">
                          <Badge className={getRoleBadgeColor(user.role)}>
                            {user.role}
                          </Badge>
                        </td>
                        <td className="py-4 text-sm text-slate-600 dark:text-slate-300">
                          {user.hospitalAffiliation || '-'}
                        </td>
                        <td className="py-4">
                          {user.isActive ? (
                            <Badge className="bg-green-100 text-green-700">
                              <div className="w-1.5 h-1.5 rounded-full bg-green-500 mr-1.5"></div>
                              Active
                            </Badge>
                          ) : (
                            <Badge variant="outline">Inactive</Badge>
                          )}
                        </td>
                        <td className="py-4 text-sm text-slate-500">
                          <div className="flex items-center gap-4">
                            <span>{user.scanCount} scans</span>
                            <span>{user.reportCount} reports</span>
                          </div>
                          {user.lastLoginAt && (
                            <p className="text-xs text-slate-400 mt-1">
                              Last login: {new Date(user.lastLoginAt).toLocaleDateString()}
                            </p>
                          )}
                        </td>
                        <td className="py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-red-500 hover:text-red-700"
                              onClick={() => deleteUserMutation.mutate(user.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Tab */}
        <TabsContent value="system">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                  <div className="flex items-center gap-3">
                    <Database className="w-5 h-5 text-blue-500" />
                    <span className="text-sm font-medium">Database</span>
                  </div>
                  <Badge className="bg-green-100 text-green-700">Connected</Badge>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                  <div className="flex items-center gap-3">
                    <Key className="w-5 h-5 text-purple-500" />
                    <span className="text-sm font-medium">API Keys</span>
                  </div>
                  <Badge className="bg-green-100 text-green-700">Configured</Badge>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-teal-500" />
                    <span className="text-sm font-medium">AI Models</span>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700">3 Deployed</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: 'Radiology AI Service', status: 'Running', uptime: '99.9%' },
                    { name: 'Ultrasound Co-Pilot', status: 'Running', uptime: '99.8%' },
                    { name: 'Causal AI Engine', status: 'Running', uptime: '99.7%' },
                    { name: 'Federated Orchestrator', status: 'Running', uptime: '99.5%' },
                  ].map((service) => (
                    <div
                      key={service.name}
                      className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                        <span className="text-sm font-medium text-slate-800 dark:text-white">
                          {service.name}
                        </span>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-green-600">{service.status}</p>
                        <p className="text-xs text-slate-500">{service.uptime} uptime</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Audit Tab */}
        <TabsContent value="audit">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Audit Log</CardTitle>
              <CardDescription>Recent system activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { action: 'LOGIN', user: 'Dr. Sarah Chen', resource: 'System', time: '2 minutes ago' },
                  { action: 'ANALYZE', user: 'Dr. James Wilson', resource: 'CT Scan #12847', time: '15 minutes ago' },
                  { action: 'CREATE', user: 'Dr. Emily Park', resource: 'Causal Report #892', time: '1 hour ago' },
                  { action: 'VIEW', user: 'Maria Rodriguez', resource: 'Patient MRN-2024-001', time: '2 hours ago' },
                  { action: 'UPDATE', user: 'System', resource: 'FL Model v2.1.0', time: '3 hours ago' },
                ].map((log, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        log.action === 'LOGIN' ? 'bg-blue-100 text-blue-600' :
                        log.action === 'ANALYZE' ? 'bg-teal-100 text-teal-600' :
                        log.action === 'CREATE' ? 'bg-green-100 text-green-600' :
                        log.action === 'VIEW' ? 'bg-purple-100 text-purple-600' :
                        'bg-amber-100 text-amber-600'
                      }`}>
                        {log.action === 'LOGIN' && <Key className="w-4 h-4" />}
                        {log.action === 'ANALYZE' && <Activity className="w-4 h-4" />}
                        {log.action === 'CREATE' && <Plus className="w-4 h-4" />}
                        {log.action === 'VIEW' && <Users className="w-4 h-4" />}
                        {log.action === 'UPDATE' && <Edit className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-800 dark:text-white">
                          {log.action}: {log.resource}
                        </p>
                        <p className="text-xs text-slate-500">by {log.user}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Clock className="w-3 h-3" />
                      {log.time}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
