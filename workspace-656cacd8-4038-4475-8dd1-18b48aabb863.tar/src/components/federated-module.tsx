'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Hospital,
  Activity,
  Wifi,
  WifiOff,
  Play,
  Pause,
  RotateCcw,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Zap,
  Globe,
  Server,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';

interface FederatedNode {
  id: string;
  name: string;
  hospital: string;
  ipAddress: string;
  status: string;
  lastSync: string | null;
  samples: number;
  roundsCompleted: number;
}

interface TrainingRun {
  id: string;
  name: string;
  modelType: string;
  status: string;
  currentRound: number;
  totalRounds: number;
  accuracy: number;
  loss: number;
  participatingNodes: number;
  startedAt: string;
}

// Simulated training progress data
const TRAINING_PROGRESS = [
  { round: 10, accuracy: 0.72, loss: 0.45 },
  { round: 20, accuracy: 0.78, loss: 0.38 },
  { round: 30, accuracy: 0.82, loss: 0.32 },
  { round: 40, accuracy: 0.85, loss: 0.28 },
  { round: 50, accuracy: 0.87, loss: 0.24 },
  { round: 60, accuracy: 0.88, loss: 0.21 },
  { round: 70, accuracy: 0.89, loss: 0.19 },
  { round: 80, accuracy: 0.90, loss: 0.17 },
  { round: 90, accuracy: 0.91, loss: 0.16 },
  { round: 100, accuracy: 0.92, loss: 0.15 },
];

export function FederatedModule() {
  const [isTraining, setIsTraining] = useState(false);
  const [currentRound, setCurrentRound] = useState(0);
  const queryClient = useQueryClient();

  // Fetch FL status
  const { data: flData, isLoading } = useQuery({
    queryKey: ['federated'],
    queryFn: async () => {
      const response = await fetch('/api/federated');
      return response.json();
    },
    refetchInterval: 5000,
  });

  // Simulate training progress
  useEffect(() => {
    if (!isTraining) return;

    const interval = setInterval(() => {
      setCurrentRound(prev => {
        if (prev >= 100) {
          setIsTraining(false);
          return prev;
        }
        return prev + 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isTraining]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ACTIVE':
        return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'TRAINING':
        return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'SYNCING':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300';
      case 'ERROR':
        return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-slate-100 text-slate-700 dark:bg-slate-900 dark:text-slate-300';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ACTIVE':
      case 'TRAINING':
        return <Wifi className="w-4 h-4" />;
      default:
        return <WifiOff className="w-4 h-4" />;
    }
  };

  if (isLoading || !flData) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const { nodes, currentRun, recentRuns } = flData;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Hospital className="w-7 h-7 text-amber-500" />
            Federated Learning Orchestrator
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Privacy-preserving distributed AI training across hospital networks
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            <Server className="w-3 h-3 mr-1" />
            FedAvg Strategy
          </Badge>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <Globe className="w-3 h-3 mr-1" />
            {nodes.filter((n: FederatedNode) => n.status === 'ACTIVE').length} Active
          </Badge>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-amber-500 to-orange-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-100 text-sm">Active Nodes</p>
                <p className="text-2xl font-bold">
                  {nodes.filter((n: FederatedNode) => n.status === 'ACTIVE').length}
                </p>
              </div>
              <Hospital className="w-8 h-8 text-amber-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-indigo-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Total Samples</p>
                <p className="text-2xl font-bold">
                  {nodes.reduce((sum: number, n: FederatedNode) => sum + (n.samples || 0), 0).toLocaleString()}
                </p>
              </div>
              <Activity className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-teal-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Rounds Completed</p>
                <p className="text-2xl font-bold">{currentRound || nodes[0]?.roundsCompleted || 45}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Global Model Acc.</p>
                <p className="text-2xl font-bold">92.1%</p>
              </div>
              <Zap className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Training Progress */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Training Progress</CardTitle>
              <div className="flex items-center gap-2">
                {isTraining ? (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsTraining(false)}
                    >
                      <Pause className="w-4 h-4 mr-1" />
                      Pause
                    </Button>
                  </>
                ) : (
                  <Button
                    size="sm"
                    onClick={() => {
                      setIsTraining(true);
                      setCurrentRound(0);
                    }}
                    className="bg-gradient-to-r from-amber-500 to-orange-500"
                  >
                    <Play className="w-4 h-4 mr-1" />
                    Start Training
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Progress Bar */}
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-slate-500">Round Progress</span>
                  <span className="font-medium">{currentRound}/100</span>
                </div>
                <Progress value={currentRound} className="h-3" />
              </div>

              {/* Training Charts */}
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={TRAINING_PROGRESS.slice(0, Math.floor(currentRound / 10) + 1)}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="round" stroke="#64748b" fontSize={12} />
                    <YAxis yAxisId="left" domain={[0.5, 1]} stroke="#64748b" fontSize={12} />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 0.6]} stroke="#64748b" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'white',
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                      }}
                    />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="accuracy"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.2}
                      name="Accuracy"
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="loss"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={false}
                      name="Loss"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Current Metrics */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                  <p className="text-xs text-blue-600 dark:text-blue-400">Current Accuracy</p>
                  <p className="text-xl font-bold text-blue-700 dark:text-blue-300">
                    {(TRAINING_PROGRESS[Math.floor(currentRound / 10)]?.accuracy * 100 || 72).toFixed(1)}%
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20">
                  <p className="text-xs text-red-600 dark:text-red-400">Current Loss</p>
                  <p className="text-xl font-bold text-red-700 dark:text-red-300">
                    {(TRAINING_PROGRESS[Math.floor(currentRound / 10)]?.loss || 0.45).toFixed(3)}
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-green-50 dark:bg-green-900/20">
                  <p className="text-xs text-green-600 dark:text-green-400">Validation AUC</p>
                  <p className="text-xl font-bold text-green-700 dark:text-green-300">
                    0.{92 + Math.floor(currentRound / 20)}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Hospital Nodes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Participating Nodes</CardTitle>
            <CardDescription>Hospital network status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {nodes.map((node: FederatedNode) => (
                <div
                  key={node.id}
                  className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${
                        node.status === 'ACTIVE' ? 'bg-green-500 animate-pulse' :
                        node.status === 'TRAINING' ? 'bg-blue-500 animate-pulse' :
                        node.status === 'ERROR' ? 'bg-red-500' :
                        'bg-slate-400'
                      }`}></div>
                      <span className="font-medium text-sm text-slate-800 dark:text-white">
                        {node.name}
                      </span>
                    </div>
                    <Badge className={getStatusColor(node.status)}>
                      {getStatusIcon(node.status)}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-500 mb-1">{node.hospital}</p>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{node.samples?.toLocaleString()} samples</span>
                    <span>{node.roundsCompleted} rounds</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Training Runs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Training History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left py-2 text-sm font-medium text-slate-500">Run Name</th>
                  <th className="text-left py-2 text-sm font-medium text-slate-500">Status</th>
                  <th className="text-left py-2 text-sm font-medium text-slate-500">Rounds</th>
                  <th className="text-left py-2 text-sm font-medium text-slate-500">Accuracy</th>
                  <th className="text-left py-2 text-sm font-medium text-slate-500">Completed</th>
                </tr>
              </thead>
              <tbody>
                {recentRuns.map((run: TrainingRun) => (
                  <tr key={run.id} className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-3 text-sm font-medium text-slate-800 dark:text-white">
                      {run.name}
                    </td>
                    <td className="py-3">
                      <Badge className={getStatusColor(run.status)}>
                        {run.status}
                      </Badge>
                    </td>
                    <td className="py-3 text-sm text-slate-600 dark:text-slate-300">
                      {run.rounds}
                    </td>
                    <td className="py-3 text-sm text-slate-600 dark:text-slate-300">
                      {run.accuracy ? `${(run.accuracy * 100).toFixed(1)}%` : '-'}
                    </td>
                    <td className="py-3 text-sm text-slate-500">
                      {run.completedAt ? new Date(run.completedAt).toLocaleDateString() : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Architecture Diagram */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Federated Architecture</CardTitle>
          <CardDescription>Privacy-preserving training pipeline</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="flex items-center gap-8">
              {/* Hospital Nodes */}
              <div className="space-y-4">
                {['MCH', 'UMC', 'RGH', 'CMH'].map((hospital, i) => (
                  <div key={hospital} className="flex items-center gap-2">
                    <div className="w-24 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-xs font-medium text-blue-700 dark:text-blue-300">
                      {hospital}
                    </div>
                    <div className="text-xs text-slate-400">
                      Local Training
                    </div>
                  </div>
                ))}
              </div>

              {/* Arrows */}
              <div className="flex flex-col items-center gap-2">
                <div className="text-xs text-slate-400 mb-4">Model Updates</div>
                {['↑', '↓', '↑', '↓'].map((arrow, i) => (
                  <div key={i} className="text-teal-500 text-lg">{arrow}</div>
                ))}
              </div>

              {/* Central Server */}
              <div className="flex flex-col items-center">
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold">
                  <div className="text-center">
                    <Server className="w-8 h-8 mx-auto mb-1" />
                    <div className="text-xs">Aggregation</div>
                    <div className="text-xs">FedAvg</div>
                  </div>
                </div>
              </div>

              {/* Output */}
              <div className="flex items-center gap-2">
                <div className="text-teal-500 text-2xl">→</div>
                <div className="w-24 h-24 rounded-lg bg-green-100 dark:bg-green-900/30 flex flex-col items-center justify-center text-xs font-medium text-green-700 dark:text-green-300">
                  <CheckCircle2 className="w-6 h-6 mb-1" />
                  Global<br/>Model
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
