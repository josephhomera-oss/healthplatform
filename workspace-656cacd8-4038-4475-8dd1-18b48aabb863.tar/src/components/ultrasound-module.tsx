'use client';

import { useState, useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  HeartPulse,
  Play,
  Pause,
  RotateCcw,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Target,
  Activity,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  Gauge,
  Video,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';

interface GuidanceData {
  viewQuality: number;
  targetView: string;
  direction: string;
  magnitude: number;
  description: string;
  anatomicalLandmarks: string[];
  confidence: number;
}

const TARGET_VIEWS = [
  { id: 'apical_4ch', name: 'Apical 4-Chamber', description: 'Cardiac - all chambers visible' },
  { id: 'apical_2ch', name: 'Apical 2-Chamber', description: 'Left atrium and ventricle' },
  { id: 'parasternal_lax', name: 'Parasternal Long Axis', description: 'LV outflow tract' },
  { id: 'parasternal_sax', name: 'Parasternal Short Axis', description: 'Cross-sectional LV view' },
  { id: 'subcostal', name: 'Subcostal 4-Chamber', description: 'Inferior cardiac view' },
];

export function UltrasoundModule() {
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [targetView, setTargetView] = useState('apical_4ch');
  const [currentGuidance, setCurrentGuidance] = useState<GuidanceData | null>(null);
  const [framesCaptured, setFramesCaptured] = useState(0);
  const [viewQuality, setViewQuality] = useState(0);
  const [simulatedProbePosition, setSimulatedProbePosition] = useState({ x: 0, y: 0, rotation: 0 });

  // Simulate real-time guidance updates
  useEffect(() => {
    if (!isSessionActive) return;

    const interval = setInterval(async () => {
      try {
        const response = await fetch('/api/ultrasound/guidance', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            currentView: 'Apical 4-Chamber',
            targetView: TARGET_VIEWS.find(v => v.id === targetView)?.name,
            probePosition: simulatedProbePosition,
            probeOrientation: { roll: 0, pitch: 0, yaw: 0 },
          }),
        });
        const data = await response.json();
        if (data.success) {
          setCurrentGuidance(data.guidance);
          setViewQuality(data.guidance.viewQuality * 100);
          setFramesCaptured(prev => prev + 1);
        }
      } catch (error) {
        console.error('Guidance error:', error);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [isSessionActive, targetView, simulatedProbePosition]);

  const handleStartSession = () => {
    setIsSessionActive(true);
    setFramesCaptured(0);
    setViewQuality(0);
  };

  const handleEndSession = () => {
    setIsSessionActive(false);
    setCurrentGuidance(null);
  };

  const getDirectionIcon = (direction: string) => {
    switch (direction) {
      case 'up':
        return <ArrowUp className="w-6 h-6" />;
      case 'down':
        return <ArrowDown className="w-6 h-6" />;
      case 'left':
        return <ArrowLeft className="w-6 h-6" />;
      case 'right':
        return <ArrowRight className="w-6 h-6" />;
      case 'rotate_cw':
        return <RotateCw className="w-6 h-6" />;
      case 'rotate_ccw':
        return <RotateCw className="w-6 h-6 scale-x-[-1]" />;
      default:
        return <Target className="w-6 h-6" />;
    }
  };

  const getQualityColor = (quality: number) => {
    if (quality >= 80) return 'text-green-600';
    if (quality >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <HeartPulse className="w-7 h-7 text-teal-500" />
            Ultrasound AI Co-Pilot
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Real-time physics-informed guidance for standardized ultrasound acquisition
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
            DRL Agent v1.8.0
          </Badge>
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            PINN Enhanced
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Ultrasound View */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Video className="w-5 h-5 text-teal-500" />
                Live Ultrasound Stream
              </CardTitle>
              <Select value={targetView} onValueChange={setTargetView}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select target view" />
                </SelectTrigger>
                <SelectContent>
                  {TARGET_VIEWS.map((view) => (
                    <SelectItem key={view.id} value={view.id}>
                      {view.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <CardDescription>
              Target: {TARGET_VIEWS.find(v => v.id === targetView)?.description}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Simulated Ultrasound Display */}
            <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
              {/* Simulated ultrasound noise pattern */}
              <div className="absolute inset-0 opacity-40">
                <div
                  className="w-full h-full"
                  style={{
                    background: `radial-gradient(ellipse at center, rgba(255,255,255,0.1) 0%, transparent 70%)`,
                  }}
                ></div>
              </div>
              
              {/* Ultrasound cone simulation */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-3/4 h-3/4 relative">
                  <div
                    className="absolute inset-0 bg-gradient-to-b from-slate-800/20 to-transparent"
                    style={{
                      clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
                    }}
                  ></div>
                  
                  {/* Simulated cardiac structures */}
                  {isSessionActive && (
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <div className="relative">
                        {/* Heart chambers simulation */}
                        <div className="w-32 h-24 border-2 border-slate-400/50 rounded-lg relative">
                          <div className="absolute top-2 left-2 w-12 h-8 border border-slate-400/40 rounded"></div>
                          <div className="absolute top-2 right-2 w-12 h-8 border border-slate-400/40 rounded"></div>
                          <div className="absolute bottom-2 left-4 w-10 h-10 border border-slate-400/40 rounded"></div>
                          <div className="absolute bottom-2 right-4 w-10 h-10 border border-slate-400/40 rounded"></div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Guidance Overlay */}
                  {isSessionActive && currentGuidance && (
                    <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10">
                      <div className="bg-black/70 backdrop-blur-sm rounded-lg px-4 py-2 flex items-center gap-3">
                        <div className={`p-2 rounded-full ${
                          currentGuidance.direction === 'hold' 
                            ? 'bg-green-500/20' 
                            : 'bg-blue-500/20 animate-pulse'
                        }`}>
                          {getDirectionIcon(currentGuidance.direction)}
                        </div>
                        <div className="text-white">
                          <p className="text-sm font-medium">{currentGuidance.description}</p>
                          <p className="text-xs text-slate-300">
                            Magnitude: {currentGuidance.magnitude}°
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Session status overlay */}
              {!isSessionActive && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                  <div className="text-center">
                    <HeartPulse className="w-16 h-16 text-teal-400 mx-auto mb-4" />
                    <p className="text-white text-lg font-medium">Ready to Start Session</p>
                    <p className="text-slate-400 text-sm mt-1">
                      Select target view and click Start
                    </p>
                  </div>
                </div>
              )}

              {/* Quality indicator */}
              {isSessionActive && (
                <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-2">
                  <div className="flex items-center gap-2 text-white">
                    <Gauge className="w-4 h-4" />
                    <span className="text-sm">Quality:</span>
                    <span className={`font-bold ${getQualityColor(viewQuality)}`}>
                      {Math.round(viewQuality)}%
                    </span>
                  </div>
                </div>
              )}

              {/* Confidence indicator */}
              {isSessionActive && currentGuidance && (
                <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-sm rounded-lg p-2">
                  <div className="flex items-center gap-2 text-white">
                    <Activity className="w-4 h-4" />
                    <span className="text-sm">AI Confidence:</span>
                    <span className="font-bold text-teal-400">
                      {Math.round(currentGuidance.confidence * 100)}%
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Control Buttons */}
            <div className="flex items-center justify-center gap-4 mt-4">
              {!isSessionActive ? (
                <Button
                  onClick={handleStartSession}
                  className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start Session
                </Button>
              ) : (
                <>
                  <Button
                    onClick={handleEndSession}
                    variant="destructive"
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    End Session
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSimulatedProbePosition({ x: 0, y: 0, rotation: 0 });
                      setFramesCaptured(0);
                    }}
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Reset Position
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Guidance Panel */}
        <div className="space-y-4">
          {/* Session Status */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Session Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-500">View Quality</span>
                    <span className={`font-medium ${getQualityColor(viewQuality)}`}>
                      {Math.round(viewQuality)}%
                    </span>
                  </div>
                  <Progress value={viewQuality} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                    <p className="text-xs text-slate-500">Frames Captured</p>
                    <p className="text-xl font-bold text-slate-800 dark:text-white">
                      {framesCaptured}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                    <p className="text-xs text-slate-500">Target View</p>
                    <p className="text-sm font-medium text-slate-800 dark:text-white">
                      {TARGET_VIEWS.find(v => v.id === targetView)?.name.split(' ')[0]}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isSessionActive ? (
                    <Badge className="bg-green-100 text-green-700">
                      <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
                      Session Active
                    </Badge>
                  ) : (
                    <Badge variant="outline">Session Inactive</Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Guidance */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">AI Guidance</CardTitle>
              <CardDescription>Real-time probe movement instructions</CardDescription>
            </CardHeader>
            <CardContent>
              {currentGuidance ? (
                <div className="space-y-4">
                  {/* Direction Indicator */}
                  <div className="flex items-center justify-center">
                    <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
                      currentGuidance.direction === 'hold'
                        ? 'bg-green-100 dark:bg-green-900/30'
                        : 'bg-blue-100 dark:bg-blue-900/30 animate-pulse'
                    }`}>
                      <div className={`text-blue-600 dark:text-blue-400 ${
                        currentGuidance.direction === 'rotate_cw' ? 'animate-spin' : ''
                      }`} style={{ animationDuration: '2s' }}>
                        {getDirectionIcon(currentGuidance.direction)}
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className="font-medium text-slate-800 dark:text-white">
                      {currentGuidance.description}
                    </p>
                    <p className="text-sm text-slate-500 mt-1">
                      Direction: <span className="font-medium">{currentGuidance.direction}</span>
                      {' | '}
                      Amount: <span className="font-medium">{currentGuidance.magnitude}°</span>
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                    <p className="text-xs text-slate-500 mb-2">Anatomical Landmarks</p>
                    <div className="space-y-1">
                      {currentGuidance.anatomicalLandmarks.map((landmark, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <CheckCircle2 className="w-3 h-3 text-green-500" />
                          <span className="text-slate-600 dark:text-slate-300">{landmark}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Target className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">Start session to receive guidance</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Probe Position Simulator */}
          {isSessionActive && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Probe Position</CardTitle>
                <CardDescription>Simulate probe movements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-slate-500">X Position</label>
                    <Slider
                      value={[simulatedProbePosition.x]}
                      onValueChange={([x]) => setSimulatedProbePosition(prev => ({ ...prev, x }))}
                      min={-100}
                      max={100}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500">Y Position</label>
                    <Slider
                      value={[simulatedProbePosition.y]}
                      onValueChange={([y]) => setSimulatedProbePosition(prev => ({ ...prev, y }))}
                      min={-100}
                      max={100}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500">Rotation</label>
                    <Slider
                      value={[simulatedProbePosition.rotation]}
                      onValueChange={([rotation]) => setSimulatedProbePosition(prev => ({ ...prev, rotation }))}
                      min={-180}
                      max={180}
                      className="mt-1"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Physics-Informed Alert */}
          <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/50">
                  <Activity className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-purple-800 dark:text-purple-300">
                    PINN Constraint Active
                  </p>
                  <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                    Ultrasound wave physics incorporated for improved guidance accuracy
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
