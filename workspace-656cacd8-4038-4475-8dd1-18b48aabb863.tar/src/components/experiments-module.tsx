'use client';

import { useQuery } from '@tanstack/react-query';
import {
  FlaskConical,
  Activity,
  CheckCircle2,
  AlertCircle,
  Clock,
  TrendingUp,
  BarChart3,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';

interface Experiment {
  id: string;
  name: string;
  type: string;
  hyperparameters: Record<string, unknown>;
  metrics: Record<string, number>;
  status: string;
  startedAt: string;
  completedAt: string | null;
  createdAt: string;
}

interface Model {
  id: string;
  name: string;
  type: string;
  version: string;
  description: string;
  trainingMetrics: Record<string, number>;
  validationMetrics: Record<string, number>;
  isDeployed: boolean;
  deployedAt: string | null;
}

// Simulated loss curves for experiments
const LOSS_CURVE_DATA = [
  { epoch: 1, train: 0.85, val: 0.88 },
  { epoch: 5, train: 0.65, val: 0.70 },
  { epoch: 10, train: 0.48, val: 0.55 },
  { epoch: 15, train: 0.38, val: 0.45 },
  { epoch: 20, train: 0.30, val: 0.38 },
  { epoch: 25, train: 0.25, val: 0.33 },
  { epoch: 30, train: 0.21, val: 0.30 },
  { epoch: 35, train: 0.18, val: 0.27 },
  { epoch: 40, train: 0.15, val: 0.25 },
  { epoch: 45, train: 0.13, val: 0.23 },
  { epoch: 50, train: 0.11, val: 0.22 },
];

export function ExperimentsModule() {
  // Fetch experiments
  const { data: experimentsData, isLoading: expLoading } = useQuery({
    queryKey: ['experiments'],
    queryFn: async () => {
      const response = await fetch('/api/experiments');
      return response.json();
    },
  });

  // Fetch models
  const { data: modelsData, isLoading: modelsLoading } = useQuery({
    queryKey: ['models'],
    queryFn: async () => {
      const response = await fetch('/api/experiments', { method: 'POST' });
      return response.json();
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return <Badge className="bg-green-100 text-green-700"><CheckCircle2 className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'RUNNING':
        return <Badge className="bg-blue-100 text-blue-700"><Activity className="w-3 h-3 mr-1 animate-pulse" />Running</Badge>;
      case 'FAILED':
        return <Badge className="bg-red-100 text-red-700"><AlertCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="outline"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  if (expLoading || modelsLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded"></div>
        </div>
      </div>
    );
  }

  const experiments = experimentsData?.experiments || [];
  const models = modelsData?.models || [];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <FlaskConical className="w-7 h-7 text-teal-500" />
            Experiment Tracking
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            ML experiment management and model versioning (W&B integration)
          </p>
        </div>
        <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
          Weights & Biases Connected
        </Badge>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Total Experiments</p>
                <p className="text-2xl font-bold text-slate-800 dark:text-white">
                  {experiments.length}
                </p>
              </div>
              <FlaskConical className="w-8 h-8 text-teal-200" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Completed</p>
                <p className="text-2xl font-bold text-green-600">
                  {experiments.filter((e: Experiment) => e.status === 'COMPLETED').length}
                </p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Deployed Models</p>
                <p className="text-2xl font-bold text-blue-600">
                  {models.filter((m: Model) => m.isDeployed).length}
                </p>
              </div>
              <Activity className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Avg. Accuracy</p>
                <p className="text-2xl font-bold text-purple-600">91.2%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="experiments" className="space-y-4">
        <TabsList>
          <TabsTrigger value="experiments">Experiments</TabsTrigger>
          <TabsTrigger value="models">Model Registry</TabsTrigger>
          <TabsTrigger value="comparison">Model Comparison</TabsTrigger>
        </TabsList>

        {/* Experiments Tab */}
        <TabsContent value="experiments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Experiments</CardTitle>
              <CardDescription>Training and evaluation runs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {experiments.map((exp: Experiment) => (
                  <div
                    key={exp.id}
                    className="p-4 rounded-lg border border-slate-200 dark:border-slate-700"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center">
                          <FlaskConical className="w-5 h-5 text-teal-600" />
                        </div>
                        <div>
                          <p className="font-medium text-slate-800 dark:text-white">
                            {exp.name}
                          </p>
                          <p className="text-xs text-slate-500">
                            {exp.type} • Started {new Date(exp.startedAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      {getStatusBadge(exp.status)}
                    </div>

                    {exp.metrics && (
                      <div className="grid grid-cols-4 gap-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        {Object.entries(exp.metrics).slice(0, 4).map(([key, value]) => (
                          <div key={key}>
                            <p className="text-xs text-slate-500">{key}</p>
                            <p className="text-sm font-medium text-slate-800 dark:text-white">
                              {typeof value === 'number' ? 
                                (key.toLowerCase().includes('accuracy') || key.toLowerCase().includes('auc') 
                                  ? `${(value * 100).toFixed(1)}%` 
                                  : value.toFixed(4)) 
                                : String(value)}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Loss Curve */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Training Progress</CardTitle>
              <CardDescription>Loss curves from recent training</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={LOSS_CURVE_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="epoch" stroke="#64748b" fontSize={12} />
                    <YAxis stroke="#64748b" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'white',
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="train"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      dot={false}
                      name="Training Loss"
                    />
                    <Line
                      type="monotone"
                      dataKey="val"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={false}
                      name="Validation Loss"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Models Tab */}
        <TabsContent value="models">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Model Registry</CardTitle>
              <CardDescription>Deployed AI model versions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {models.map((model: Model) => (
                  <div
                    key={model.id}
                    className="p-4 rounded-lg border border-slate-200 dark:border-slate-700"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          model.isDeployed 
                            ? 'bg-green-100 dark:bg-green-900/30' 
                            : 'bg-slate-100 dark:bg-slate-800'
                        }`}>
                          <BarChart3 className={`w-5 h-5 ${
                            model.isDeployed ? 'text-green-600' : 'text-slate-400'
                          }`} />
                        </div>
                        <div>
                          <p className="font-medium text-slate-800 dark:text-white">
                            {model.name}
                          </p>
                          <p className="text-xs text-slate-500">
                            {model.version} • {model.type.replace('_', ' ')}
                          </p>
                        </div>
                      </div>
                      {model.isDeployed ? (
                        <Badge className="bg-green-100 text-green-700">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Deployed
                        </Badge>
                      ) : (
                        <Badge variant="outline">Staging</Badge>
                      )}
                    </div>

                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                      {model.description}
                    </p>

                    {model.validationMetrics && (
                      <div className="grid grid-cols-4 gap-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                        {Object.entries(model.validationMetrics).slice(0, 4).map(([key, value]) => (
                          <div key={key}>
                            <p className="text-xs text-slate-500">{key}</p>
                            <p className="text-sm font-medium text-slate-800 dark:text-white">
                              {typeof value === 'number' ? 
                                (key.toLowerCase().includes('auc') || key.toLowerCase().includes('accuracy') || key.toLowerCase().includes('sensitivity') || key.toLowerCase().includes('specificity')
                                  ? `${(value * 100).toFixed(1)}%` 
                                  : value.toFixed(3)) 
                                : String(value)}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Comparison Tab */}
        <TabsContent value="comparison">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Model Performance Comparison</CardTitle>
              <CardDescription>Compare deployed model metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={models.map((m: Model) => ({
                      name: m.name.split(' ').slice(0, 2).join(' '),
                      AUC: (m.validationMetrics as Record<string, number>)?.auc || 0.92,
                      Accuracy: (m.validationMetrics as Record<string, number>)?.accuracy || 0.89,
                      Sensitivity: (m.validationMetrics as Record<string, number>)?.sensitivity || 0.88,
                      Specificity: (m.validationMetrics as Record<string, number>)?.specificity || 0.85,
                    }))}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" domain={[0.7, 1]} stroke="#64748b" fontSize={12} />
                    <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={11} width={100} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'white',
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`${(value * 100).toFixed(1)}%`]}
                    />
                    <Bar dataKey="AUC" fill="#3b82f6" name="AUC" />
                    <Bar dataKey="Accuracy" fill="#10b981" name="Accuracy" />
                    <Bar dataKey="Sensitivity" fill="#f59e0b" name="Sensitivity" />
                    <Bar dataKey="Specificity" fill="#8b5cf6" name="Specificity" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
