'use client';

import { useQuery } from '@tanstack/react-query';
import {
  Activity,
  Brain,
  HeartPulse,
  Hospital,
  TrendingUp,
  Users,
  Zap,
  AlertCircle,
  CheckCircle2,
  Clock,
  FileText,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from 'recharts';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

interface DashboardData {
  stats: {
    totalPatients: number;
    totalScans: number;
    completedScans: number;
    processingScans: number;
    totalReports: number;
    activeNodes: number;
    totalNodes: number;
    avgAccuracy: number;
  };
  scanTypes: Array<{ type: string; count: number }>;
  recentScans: Array<{
    id: string;
    patientName: string;
    scanType: string;
    bodyPart: string;
    status: string;
    diagnosis?: string;
    confidence?: number;
    createdAt: string;
  }>;
  recentExperiments: Array<{
    id: string;
    name: string;
    type: string;
    status: string;
    metrics: string;
    createdAt: string;
  }>;
  processingTrends: Array<{ date: string; avgTime: number }>;
  models: Array<{
    id: string;
    name: string;
    version: string;
    type: string;
    validationMetrics: string;
  }>;
}

export function Dashboard() {
  const { data, isLoading } = useQuery<DashboardData>({
    queryKey: ['dashboard'],
    queryFn: async () => {
      const response = await fetch('/api/dashboard');
      return response.json();
    },
    refetchInterval: 30000,
  });

  if (isLoading || !data) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 w-64 bg-slate-200 dark:bg-slate-700 rounded mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-slate-200 dark:bg-slate-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const { stats, scanTypes, recentScans, recentExperiments, processingTrends, models } = data;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'PROCESSING':
        return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300';
      case 'FAILED':
        return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-700 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white">
            Healthcare AI Diagnostics Dashboard
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Real-time monitoring of AI-powered medical imaging analysis
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
            All Systems Operational
          </Badge>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Total Scans</p>
                <p className="text-3xl font-bold">{stats.totalScans}</p>
              </div>
              <Activity className="w-10 h-10 text-blue-200" />
            </div>
            <div className="mt-4 flex items-center text-sm text-blue-100">
              <TrendingUp className="w-4 h-4 mr-1" />
              <span>+12% from last week</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-teal-500 to-teal-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-teal-100 text-sm">AI Accuracy</p>
                <p className="text-3xl font-bold">{stats.avgAccuracy}%</p>
              </div>
              <Brain className="w-10 h-10 text-teal-200" />
            </div>
            <div className="mt-4">
              <Progress value={stats.avgAccuracy} className="h-2 bg-teal-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Active Nodes</p>
                <p className="text-3xl font-bold">{stats.activeNodes}/{stats.totalNodes}</p>
              </div>
              <Hospital className="w-10 h-10 text-purple-200" />
            </div>
            <div className="mt-4 flex items-center text-sm text-purple-100">
              <Zap className="w-4 h-4 mr-1" />
              <span>Federated Learning Active</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-100 text-sm">Processing</p>
                <p className="text-3xl font-bold">{stats.processingScans}</p>
              </div>
              <Clock className="w-10 h-10 text-amber-200 animate-spin" style={{ animationDuration: '3s' }} />
            </div>
            <div className="mt-4 flex items-center text-sm text-amber-100">
              <span>{stats.completedScans} completed today</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Processing Time Trends */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              Processing Performance
            </CardTitle>
            <CardDescription>Average processing time trend (seconds)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={processingTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgTime"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Scan Types Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-teal-500" />
              Scan Types Distribution
            </CardTitle>
            <CardDescription>Breakdown by imaging modality</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={scanTypes}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="count"
                    nameKey="type"
                  >
                    {scanTypes.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {scanTypes.map((item, index) => (
                <div key={item.type} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  ></div>
                  <span className="text-sm text-slate-600 dark:text-slate-300">
                    {item.type}: {item.count}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Scans */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HeartPulse className="w-5 h-5 text-red-500" />
              Recent Scans
            </CardTitle>
            <CardDescription>Latest imaging analyses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentScans.map((scan) => (
                <div
                  key={scan.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                      <Activity className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-800 dark:text-white text-sm">
                        {scan.patientName}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {scan.scanType} - {scan.bodyPart}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={getStatusColor(scan.status)}>
                      {scan.status}
                    </Badge>
                    {scan.confidence && (
                      <p className="text-xs text-slate-500 mt-1">
                        {Math.round(scan.confidence * 100)}% confidence
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Model Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-500" />
              Deployed Models
            </CardTitle>
            <CardDescription>Current AI model performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={models.map(m => {
                  const metrics = JSON.parse(m.validationMetrics as string || '{}');
                  return {
                    name: m.name.split(' ').slice(0, 2).join(' '),
                    AUC: metrics.auc || metrics.accuracy || 0.9,
                    Sensitivity: metrics.sensitivity || 0.88,
                    Specificity: metrics.specificity || 0.85,
                  };
                })} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis type="number" domain={[0, 1]} stroke="#64748b" fontSize={12} />
                  <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={10} width={80} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="AUC" fill="#3b82f6" />
                  <Bar dataKey="Sensitivity" fill="#10b981" />
                  <Bar dataKey="Specificity" fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Access key functions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button className="p-4 rounded-lg border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-600 transition-colors text-center">
              <Activity className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">New CT Analysis</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-teal-400 dark:hover:border-teal-600 transition-colors text-center">
              <HeartPulse className="w-8 h-8 mx-auto mb-2 text-teal-500" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">Start Ultrasound</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-purple-400 dark:hover:border-purple-600 transition-colors text-center">
              <Brain className="w-8 h-8 mx-auto mb-2 text-purple-500" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">Causal Analysis</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-amber-400 dark:hover:border-amber-600 transition-colors text-center">
              <FileText className="w-8 h-8 mx-auto mb-2 text-amber-500" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">View Reports</p>
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
