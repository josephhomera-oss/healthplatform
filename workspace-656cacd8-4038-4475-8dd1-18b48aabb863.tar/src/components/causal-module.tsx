'use client';

import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Brain,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  GitBranch,
  Activity,
  Target,
  Loader2,
  CheckCircle2,
  AlertCircle,
  BarChart3,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
} from 'recharts';

interface Patient {
  id: string;
  medicalRecordNumber: string;
  fullName: string;
  dateOfBirth: string;
  gender: string;
  scanCount: number;
}

interface CausalReport {
  id: string;
  patient: { name: string; mrn: string };
  treatmentType: string;
  individualTreatmentEffect: number;
  status: string;
  createdAt: string;
}

const TREATMENT_TYPES = [
  { id: 'immunotherapy', name: 'Immunotherapy', description: 'Pembrolizumab-based treatment' },
  { id: 'chemotherapy', name: 'Chemotherapy', description: 'Standard platinum-based regimen' },
  { id: 'targeted', name: 'Targeted Therapy', description: 'EGFR/ALK inhibitor therapy' },
  { id: 'radiation', name: 'Radiation Therapy', description: 'External beam radiation' },
  { id: 'combination', name: 'Combination Therapy', description: 'Multi-modal treatment approach' },
];

// Simulated longitudinal data
const LONGITUDINAL_DATA = [
  { week: 0, tumorSize: 45, metabolicActivity: 8.2 },
  { week: 4, tumorSize: 42, metabolicActivity: 7.5 },
  { week: 8, tumorSize: 38, metabolicActivity: 6.8 },
  { week: 12, tumorSize: 32, metabolicActivity: 5.9 },
  { week: 16, tumorSize: 28, metabolicActivity: 5.2 },
  { week: 20, tumorSize: 25, metabolicActivity: 4.6 },
  { week: 24, tumorSize: 22, metabolicActivity: 4.1 },
];

export function CausalModule() {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedTreatment, setSelectedTreatment] = useState('immunotherapy');
  const [analysisResult, setAnalysisResult] = useState<{
    individualTreatmentEffect: number;
    confidenceInterval: [number, number];
    causalFactors: Array<{ factor: string; contribution: number; direction: string }>;
    actualOutcome: string;
    counterfactualOutcome: string;
    recommendations: string[];
  } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const queryClient = useQueryClient();

  // Fetch patients
  const { data: patientsData } = useQuery({
    queryKey: ['patients'],
    queryFn: async () => {
      const response = await fetch('/api/patients?limit=50');
      return response.json();
    },
  });

  // Fetch existing reports
  const { data: reportsData } = useQuery({
    queryKey: ['causal-reports'],
    queryFn: async () => {
      const response = await fetch('/api/causal/predict');
      return response.json();
    },
  });

  // Causal prediction mutation
  const predictMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/causal/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: selectedPatient?.id,
          treatmentType: TREATMENT_TYPES.find(t => t.id === selectedTreatment)?.name,
          baselineMetrics: { tumorSize: 45, metabolicActivity: 8.2 },
          confounders: ['age', 'tumor_size', 'prior_treatment'],
        }),
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        setAnalysisResult(data.report);
        setIsAnalyzing(false);
        queryClient.invalidateQueries({ queryKey: ['causal-reports'] });
      }
    },
  });

  const handleAnalyze = useCallback(() => {
    if (selectedPatient) {
      setIsAnalyzing(true);
      predictMutation.mutate();
    }
  }, [selectedPatient, predictMutation]);

  const getContributionColor = (contribution: number) => {
    if (contribution >= 0.3) return 'bg-green-500';
    if (contribution >= 0.2) return 'bg-blue-500';
    return 'bg-slate-400';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Brain className="w-7 h-7 text-purple-500" />
            Causal AI Treatment Prediction
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Individual Treatment Effect estimation with counterfactual analysis
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            Causal Transformer v1.2.0
          </Badge>
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            SCM Framework
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient & Treatment Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Patient Selection</CardTitle>
            <CardDescription>Choose a patient for causal analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {patientsData?.patients?.slice(0, 5).map((patient: Patient) => (
                  <button
                    key={patient.id}
                    onClick={() => setSelectedPatient(patient)}
                    className={`w-full p-3 rounded-lg text-left transition-colors ${
                      selectedPatient?.id === patient.id
                        ? 'bg-purple-50 dark:bg-purple-900/30 border-2 border-purple-500'
                        : 'bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-slate-800 dark:text-white text-sm">
                          {patient.fullName}
                        </p>
                        <p className="text-xs text-slate-500">{patient.medicalRecordNumber}</p>
                      </div>
                      <Badge variant="outline" className="text-xs">{patient.scanCount} scans</Badge>
                    </div>
                  </button>
                ))}
              </div>

              <Separator />

              <div>
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Treatment Type
                </label>
                <Select value={selectedTreatment} onValueChange={setSelectedTreatment}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TREATMENT_TYPES.map((treatment) => (
                      <SelectItem key={treatment.id} value={treatment.id}>
                        {treatment.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500 mt-1">
                  {TREATMENT_TYPES.find(t => t.id === selectedTreatment)?.description}
                </p>
              </div>

              <Button
                onClick={handleAnalyze}
                disabled={!selectedPatient || isAnalyzing}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Running Causal Analysis...
                  </>
                ) : (
                  <>
                    <GitBranch className="w-4 h-4 mr-2" />
                    Generate Causal Report
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Analysis Results */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Treatment Effect Analysis</CardTitle>
            <CardDescription>
              Individual Treatment Effect (ITE) estimation with confidence intervals
            </CardDescription>
          </CardHeader>
          <CardContent>
            {analysisResult ? (
              <div className="space-y-6">
                {/* ITE Display */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                    <p className="text-sm opacity-80">Individual Treatment Effect</p>
                    <p className="text-3xl font-bold">
                      +{(analysisResult.individualTreatmentEffect * 100).toFixed(0)}%
                    </p>
                    <p className="text-xs opacity-70 mt-1">Treatment benefit</p>
                  </div>
                  <div className="p-4 rounded-lg bg-slate-100 dark:bg-slate-800">
                    <p className="text-sm text-slate-500">95% Confidence Interval</p>
                    <p className="text-xl font-bold text-slate-800 dark:text-white">
                      [{(analysisResult.confidenceInterval[0] * 100).toFixed(0)}%, {(analysisResult.confidenceInterval[1] * 100).toFixed(0)}%]
                    </p>
                    <p className="text-xs text-slate-500 mt-1">Statistical significance</p>
                  </div>
                  <div className="p-4 rounded-lg bg-green-100 dark:bg-green-900/30">
                    <p className="text-sm text-green-600 dark:text-green-400">Treatment Response</p>
                    <p className="text-xl font-bold text-green-700 dark:text-green-300">
                      Positive
                    </p>
                    <p className="text-xs text-green-600 dark:text-green-400 mt-1">Predicted outcome</p>
                  </div>
                </div>

                {/* Counterfactual Comparison */}
                <div className="p-4 rounded-lg border-2 border-slate-200 dark:border-slate-700">
                  <h4 className="font-medium text-slate-800 dark:text-white mb-3 flex items-center gap-2">
                    <GitBranch className="w-4 h-4" />
                    Counterfactual Analysis
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-green-50 dark:bg-green-900/20">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingDown className="w-4 h-4 text-green-500" />
                        <span className="text-sm font-medium text-green-700 dark:text-green-400">
                          With Treatment
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-300">
                        {analysisResult.actualOutcome}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-red-500" />
                        <span className="text-sm font-medium text-red-700 dark:text-red-400">
                          Without Treatment
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-300">
                        {analysisResult.counterfactualOutcome}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Causal Factors */}
                <div>
                  <h4 className="font-medium text-slate-800 dark:text-white mb-3 flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Causal Factor Attribution
                  </h4>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analysisResult.causalFactors} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis type="number" domain={[0, 0.5]} stroke="#64748b" fontSize={12} />
                        <YAxis dataKey="factor" type="category" stroke="#64748b" fontSize={11} width={120} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'white',
                            border: '1px solid #e2e8f0',
                            borderRadius: '8px',
                          }}
                          formatter={(value: number) => [`${(value * 100).toFixed(0)}%`, 'Contribution']}
                        />
                        <Bar dataKey="contribution" radius={[0, 4, 4, 0]}>
                          {analysisResult.causalFactors.map((entry, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={entry.direction === 'positive' ? '#10b981' : '#ef4444'}
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800">
                  <h4 className="font-medium text-slate-800 dark:text-white mb-2">
                    Clinical Recommendations
                  </h4>
                  <div className="space-y-2">
                    {analysisResult.recommendations.map((rec, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5" />
                        <span className="text-sm text-slate-600 dark:text-slate-300">{rec}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-16">
                <Brain className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-600 dark:text-slate-400">
                  No Analysis Results
                </h3>
                <p className="text-slate-500 dark:text-slate-500 mt-2">
                  Select a patient and treatment to generate causal predictions
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Longitudinal Visualization */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-500" />
            Longitudinal Tumor Response
          </CardTitle>
          <CardDescription>Simulated treatment progression over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={LONGITUDINAL_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="week" stroke="#64748b" fontSize={12} label={{ value: 'Weeks', position: 'bottom', offset: -5 }} />
                <YAxis yAxisId="left" stroke="#64748b" fontSize={12} label={{ value: 'Tumor Size (mm)', angle: -90, position: 'insideLeft' }} />
                <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={12} label={{ value: 'SUV (Metabolic)', angle: 90, position: 'insideRight' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                  }}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="tumorSize"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', strokeWidth: 2 }}
                  name="Tumor Size"
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="metabolicActivity"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={{ fill: '#10b981', strokeWidth: 2 }}
                  name="Metabolic Activity"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Causal Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {reportsData?.reports?.slice(0, 5).map((report: CausalReport) => (
              <div
                key={report.id}
                className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <Brain className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-800 dark:text-white text-sm">
                      {report.patient.name}
                    </p>
                    <p className="text-xs text-slate-500">{report.treatmentType}</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className={`${
                    report.individualTreatmentEffect > 0.3
                      ? 'bg-green-100 text-green-700'
                      : 'bg-amber-100 text-amber-700'
                  }`}>
                    ITE: +{(report.individualTreatmentEffect * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
