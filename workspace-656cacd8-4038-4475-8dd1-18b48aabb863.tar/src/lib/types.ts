// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// Pagination
export interface PaginationParams {
  page?: number
  limit?: number
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
  search?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

// Radiology Analysis Types
export interface RadiologyAnalysisRequest {
  scanId: string
  priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT'
  includeHeatmap?: boolean
}

export interface RadiologyAnalysisResponse {
  diagnosis: string
  diagnosisCode: string
  confidence: number
  severity: 'BENIGN' | 'LOW_RISK' | 'MODERATE_RISK' | 'HIGH_RISK' | 'MALIGNANT'
  findings: string[]
  recommendations: string[]
  heatmapBase64?: string
  roiCoordinates: { x: number; y: number; width: number; height: number }[]
  processingTime: number
  modelVersion: string
}

// Ultrasound Types
export interface UltrasoundGuidance {
  viewQuality: number
  probePosition: {
    optimal: string
    current: string
    adjustment: string
  }
  annotations: {
    type: 'arrow' | 'circle' | 'text' | 'region'
    x: number
    y: number
    label?: string
    color?: string
  }[]
  recommendations: string[]
  capturedFrame?: string
}

export interface UltrasoundSession {
  id: string
  patientId: string | null
  sonographerId: string
  status: 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'CANCELLED'
  viewQuality: number | null
  probePosition: string | null
  guidanceNotes: string | null
  capturedFrames: number
  startedAt: string
  endedAt: string | null
}

// Causal Inference Types
export interface CausalPredictionRequest {
  patientId: string
  treatmentType: string
  baselineMetrics: Record<string, number>
  treatmentDuration: number // in days
}

export interface CausalPredictionResponse {
  actualOutcome: string
  actualOutcomeScore: number
  counterfactualOutcome: string
  counterfactualScore: number
  individualTreatmentEffect: number
  confidenceInterval: [number, number]
  causalFactors: {
    factor: string
    contribution: number
    confidence: number
  }[]
  recommendedTreatment?: string
  modelVersion: string
}

// Federated Learning Types
export interface FederatedTrainingStatus {
  currentRound: number
  totalRounds: number
  participatingNodes: number
  aggregationStatus: 'WAITING' | 'AGGREGATING' | 'COMPLETED' | 'FAILED'
  globalModelVersion: string
  roundMetrics: {
    round: number
    accuracy: number
    loss: number
    participatingNodes: string[]
  }[]
}

export interface FederatedNodeStatus {
  nodeId: string
  nodeName: string
  hospitalName: string
  status: 'ACTIVE' | 'INACTIVE' | 'SYNCING' | 'ERROR'
  lastSync: string | null
  localDataSize: number
  localModelAccuracy: number | null
  currentRound: number | null
  gradientNorm: number | null
}

// Experiment Tracking Types
export interface ExperimentMetric {
  epoch: number
  trainingLoss: number
  validationLoss: number
  trainingAccuracy: number
  validationAccuracy: number
  learningRate: number
  timestamp: string
}

export interface ExperimentDetails {
  id: string
  name: string
  description: string
  modelType: string
  status: string
  hyperparameters: Record<string, unknown>
  metrics: ExperimentMetric[]
  startTime: string
  endTime: string | null
  duration: number | null
  bestEpoch: number
  bestValidationAccuracy: number
  creator: string
}

// Dashboard Statistics
export interface DashboardStatistics {
  overview: {
    totalScans: number
    scansToday: number
    pendingScans: number
    completedAnalyses: number
    averageAccuracy: number
    activeNodes: number
    totalPatients: number
    modelsDeployed: number
  }
  recentActivity: {
    id: string
    type: 'scan' | 'analysis' | 'treatment' | 'experiment'
    description: string
    timestamp: string
    status: string
  }[]
  performanceMetrics: {
    date: string
    scans: number
    accuracy: number
    processingTime: number
  }[]
  scanDistribution: {
    type: string
    count: number
    percentage: number
  }[]
  nodeStatus: {
    nodeId: string
    nodeName: string
    status: string
    contributions: number
  }[]
}

// Audit Log Types
export interface AuditLogEntry {
  id: string
  userId: string | null
  userName: string | null
  action: string
  entityType: string | null
  entityId: string | null
  details: Record<string, unknown> | null
  ipAddress: string | null
  timestamp: string
}

// System Health
export interface SystemHealth {
  status: 'healthy' | 'degraded' | 'unhealthy'
  services: {
    name: string
    status: 'up' | 'down' | 'degraded'
    latency: number
    lastCheck: string
    message?: string
  }[]
  database: {
    status: 'connected' | 'disconnected'
    latency: number
    activeConnections: number
  }
  ai: {
    status: 'available' | 'unavailable'
    modelVersion: string
    queueSize: number
  }
  federated: {
    activeNodes: number
    totalNodes: number
    currentRound: number | null
  }
}
