import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// User types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'ADMIN' | 'RADIOLOGIST' | 'SONOGRAPHER' | 'RESEARCHER';
  hospitalAffiliation?: string;
  avatar?: string;
}

// UI State
interface UIState {
  sidebarOpen: boolean;
  activeModule: 'dashboard' | 'radiology' | 'ultrasound' | 'causal' | 'federated' | 'experiments' | 'admin';
  theme: 'light' | 'dark';
  toggleSidebar: () => void;
  setActiveModule: (module: UIState['activeModule']) => void;
  setTheme: (theme: 'light' | 'dark') => void;
}

// Auth State
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (user: User) => void;
  logout: () => void;
  setLoading: (loading: boolean) => void;
}

// Notification State
interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: Date;
}

interface NotificationState {
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
}

// Scan Analysis State
interface ScanAnalysis {
  scanId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  result?: {
    diagnosis: string;
    confidence: number;
    findings: Array<{
      type: string;
      location: string;
      severity: string;
      description: string;
    }>;
  };
}

interface ScanState {
  currentScan: ScanAnalysis | null;
  recentScans: ScanAnalysis[];
  setCurrentScan: (scan: ScanAnalysis | null) => void;
  updateScanProgress: (scanId: string, progress: number, status?: ScanAnalysis['status']) => void;
  addRecentScan: (scan: ScanAnalysis) => void;
}

// Ultrasound Session State
interface UltrasoundSession {
  sessionId: string;
  isActive: boolean;
  targetView: string;
  currentQuality: number;
  framesCaptured: number;
  guidance: {
    direction: string;
    magnitude: number;
    description: string;
  } | null;
}

interface UltrasoundState {
  session: UltrasoundSession | null;
  startSession: (targetView: string) => void;
  endSession: () => void;
  updateQuality: (quality: number) => void;
  updateGuidance: (guidance: UltrasoundSession['guidance']) => void;
  incrementFrames: () => void;
}

// Federated Learning State
interface FLNode {
  id: string;
  name: string;
  hospital: string;
  status: 'active' | 'inactive' | 'training' | 'error';
  lastSync: Date | null;
  samples: number;
}

interface FLTrainingRun {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'paused' | 'completed' | 'failed';
  currentRound: number;
  totalRounds: number;
  accuracy: number;
  loss: number;
}

interface FederatedState {
  nodes: FLNode[];
  currentRun: FLTrainingRun | null;
  setNodes: (nodes: FLNode[]) => void;
  setCurrentRun: (run: FLTrainingRun | null) => void;
  updateRunProgress: (round: number, accuracy: number, loss: number) => void;
}

// Create stores
export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      activeModule: 'dashboard',
      theme: 'light',
      toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setActiveModule: (module) => set({ activeModule: module }),
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: 'healthcare-ui-storage',
      partialize: (state) => ({ theme: state.theme, sidebarOpen: state.sidebarOpen }),
    }
  )
);

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
      setLoading: (isLoading) => set({ isLoading }),
    }),
    {
      name: 'healthcare-auth-storage',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  addNotification: (notification) => {
    const id = Math.random().toString(36).substring(7);
    set((state) => ({
      notifications: [
        ...state.notifications,
        { ...notification, id, timestamp: new Date() },
      ],
    }));
    // Auto-remove after 5 seconds
    setTimeout(() => {
      set((state) => ({
        notifications: state.notifications.filter((n) => n.id !== id),
      }));
    }, 5000);
  },
  removeNotification: (id) =>
    set((state) => ({
      notifications: state.notifications.filter((n) => n.id !== id),
    })),
  clearNotifications: () => set({ notifications: [] }),
}));

export const useScanStore = create<ScanState>((set) => ({
  currentScan: null,
  recentScans: [],
  setCurrentScan: (scan) => set({ currentScan: scan }),
  updateScanProgress: (scanId, progress, status) =>
    set((state) => {
      if (state.currentScan?.scanId === scanId) {
        return {
          currentScan: {
            ...state.currentScan,
            progress,
            status: status || state.currentScan.status,
          },
        };
      }
      return state;
    }),
  addRecentScan: (scan) =>
    set((state) => ({
      recentScans: [scan, ...state.recentScans].slice(0, 10),
    })),
}));

export const useUltrasoundStore = create<UltrasoundState>((set) => ({
  session: null,
  startSession: (targetView) =>
    set({
      session: {
        sessionId: Math.random().toString(36).substring(7),
        isActive: true,
        targetView,
        currentQuality: 0,
        framesCaptured: 0,
        guidance: null,
      },
    }),
  endSession: () => set({ session: null }),
  updateQuality: (quality) =>
    set((state) => ({
      session: state.session ? { ...state.session, currentQuality: quality } : null,
    })),
  updateGuidance: (guidance) =>
    set((state) => ({
      session: state.session ? { ...state.session, guidance } : null,
    })),
  incrementFrames: () =>
    set((state) => ({
      session: state.session
        ? { ...state.session, framesCaptured: state.session.framesCaptured + 1 }
        : null,
    })),
}));

export const useFederatedStore = create<FederatedState>((set) => ({
  nodes: [],
  currentRun: null,
  setNodes: (nodes) => set({ nodes }),
  setCurrentRun: (run) => set({ currentRun: run }),
  updateRunProgress: (round, accuracy, loss) =>
    set((state) => ({
      currentRun: state.currentRun
        ? { ...state.currentRun, currentRound: round, accuracy, loss }
        : null,
    })),
}));
