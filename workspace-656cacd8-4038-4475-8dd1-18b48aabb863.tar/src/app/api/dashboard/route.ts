import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function GET() {
  try {
    // Get dashboard statistics
    const [
      totalPatients,
      totalScans,
      completedScans,
      processingScans,
      totalReports,
      activeNodes,
      totalNodes,
      recentScans,
      recentExperiments,
    ] = await Promise.all([
      prisma.patient.count(),
      prisma.scan.count(),
      prisma.scan.count({ where: { status: 'COMPLETED' } }),
      prisma.scan.count({ where: { status: 'PROCESSING' } }),
      prisma.causalReport.count({ where: { status: 'COMPLETED' } }),
      prisma.federatedNode.count({ where: { status: 'ACTIVE' } }),
      prisma.federatedNode.count(),
      prisma.scan.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: {
          patient: true,
          analysisResult: true,
        },
      }),
      prisma.experimentLog.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
      }),
    ]);

    // Get scan type distribution
    const scanTypes = await prisma.scan.groupBy({
      by: ['scanType'],
      _count: true,
    });

    // Get model performance metrics
    const models = await prisma.modelVersion.findMany({
      where: { isDeployed: true },
    });

    // Calculate average accuracy
    const modelMetrics = models.map((m) => {
      const valMetrics = m.validationMetrics as Record<string, number> | null;
      return valMetrics?.auc || 0;
    }).filter(Boolean);

    const avgAccuracy = modelMetrics.length > 0
      ? modelMetrics.reduce((a, b) => a + b, 0) / modelMetrics.length
      : 0;

    // Get processing time trends (simulated for demo)
    const processingTrends = [
      { date: '2024-01', avgTime: 2.8 },
      { date: '2024-02', avgTime: 2.5 },
      { date: '2024-03', avgTime: 2.3 },
      { date: '2024-04', avgTime: 2.1 },
      { date: '2024-05', avgTime: 1.9 },
      { date: '2024-06', avgTime: 1.7 },
    ];

    return NextResponse.json({
      stats: {
        totalPatients,
        totalScans,
        completedScans,
        processingScans,
        totalReports,
        activeNodes,
        totalNodes,
        avgAccuracy: Math.round(avgAccuracy * 100),
      },
      scanTypes: scanTypes.map((s) => ({
        type: s.scanType,
        count: s._count,
      })),
      recentScans: recentScans.map((s) => ({
        id: s.id,
        patientName: `${s.patient.firstName} ${s.patient.lastName}`,
        scanType: s.scanType,
        bodyPart: s.bodyPart,
        status: s.status,
        createdAt: s.createdAt,
        diagnosis: s.analysisResult?.primaryDiagnosis,
        confidence: s.analysisResult?.confidence,
      })),
      recentExperiments: recentExperiments.map((e) => ({
        id: e.id,
        name: e.experimentName,
        type: e.experimentType,
        status: e.status,
        metrics: e.metrics,
        createdAt: e.createdAt,
      })),
      processingTrends,
      models: models.map((m) => ({
        id: m.id,
        name: m.modelName,
        version: m.version,
        type: m.modelType,
        validationMetrics: m.validationMetrics,
      })),
    });
  } catch (error) {
    console.error('Dashboard API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch dashboard data' },
      { status: 500 }
    );
  }
}
