import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const patient = await db.patient.findUnique({
      where: { id },
      include: {
        scans: {
          orderBy: { createdAt: 'desc' },
          take: 10
        },
        causalReports: {
          orderBy: { createdAt: 'desc' },
          take: 5
        },
        treatmentRecords: {
          orderBy: { createdAt: 'desc' },
          take: 10
        }
      }
    })

    if (!patient) {
      return NextResponse.json(
        { success: false, error: 'Patient not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: patient
    })
  } catch (error) {
    console.error('Get patient error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch patient' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    const patient = await db.patient.update({
      where: { id },
      data: body
    })

    return NextResponse.json({
      success: true,
      data: patient,
      message: 'Patient updated successfully'
    })
  } catch (error) {
    console.error('Update patient error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update patient' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    await db.patient.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Patient deleted successfully'
    })
  } catch (error) {
    console.error('Delete patient error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete patient' },
      { status: 500 }
    )
  }
}
