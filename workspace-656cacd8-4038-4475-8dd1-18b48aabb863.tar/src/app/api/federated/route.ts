import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { coordinateFLRound } from '@/lib/ai-service';

// GET /api/federated - Get federated learning status
export async function GET(request: NextRequest) {
  try {
    const [nodes, currentRun, recentRuns] = await Promise.all([
      prisma.federatedNode.findMany({
        orderBy: { nodeName: 'asc' },
      }),
      prisma.federatedTrainingRun.findFirst({
        where: { status: 'RUNNING' },
        include: { nodes: true },
      }),
      prisma.federatedTrainingRun.findMany({
        where: { status: { in: ['COMPLETED', 'PAUSED'] } },
        take: 5,
        orderBy: { createdAt: 'desc' },
      }),
    ]);

    return NextResponse.json({
      nodes: nodes.map((n) => ({
        id: n.id,
        name: n.nodeName,
        hospital: n.hospitalName,
        ipAddress: n.ipAddress,
        status: n.status,
        lastSync: n.lastSyncAt,
        samples: n.localDataSize,
        roundsCompleted: n.trainingRoundsCompleted,
      })),
      currentRun: currentRun ? {
        id: currentRun.id,
        name: currentRun.runName,
        modelType: currentRun.modelType,
        status: currentRun.status,
        currentRound: currentRun.currentRound,
        totalRounds: currentRun.totalRounds,
        accuracy: currentRun.globalModelAccuracy,
        loss: currentRun.globalModelLoss,
        participatingNodes: currentRun.nodes.length,
        startedAt: currentRun.startedAt,
      } : null,
      recentRuns: recentRuns.map((r) => ({
        id: r.id,
        name: r.runName,
        status: r.status,
        rounds: r.totalRounds,
        accuracy: r.globalModelAccuracy,
        completedAt: r.completedAt,
      })),
    });
  } catch (error) {
    console.error('Get FL status error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch FL status' },
      { status: 500 }
    );
  }
}

// POST /api/federated - Start new training run
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { name, modelType, totalRounds, aggregationStrategy, learningRate, nodeIds } = data;

    // Create training run
    const run = await prisma.federatedTrainingRun.create({
      data: {
        runName: name,
        modelType,
        totalRounds: totalRounds || 100,
        aggregationStrategy: aggregationStrategy || 'FedAvg',
        learningRate: learningRate || 0.001,
        status: 'RUNNING',
        currentRound: 0,
        participatingNodeIds: JSON.stringify(nodeIds),
        startedAt: new Date(),
      },
    });

    // Update nodes to training status
    if (nodeIds?.length > 0) {
      await prisma.federatedNode.updateMany({
        where: { id: { in: nodeIds } },
        data: { status: 'TRAINING' },
      });
    }

    return NextResponse.json({
      success: true,
      run: {
        id: run.id,
        name: run.runName,
        status: run.status,
        totalRounds: run.totalRounds,
        startedAt: run.startedAt,
      },
    });
  } catch (error) {
    console.error('Start FL run error:', error);
    return NextResponse.json(
      { error: 'Failed to start training run' },
      { status: 500 }
    );
  }
}

// PUT /api/federated - Update training round
export async function PUT(request: NextRequest) {
  try {
    const data = await request.json();
    const { runId, action, round, accuracy, loss } = data;

    if (action === 'pause') {
      await prisma.federatedTrainingRun.update({
        where: { id: runId },
        data: { status: 'PAUSED' },
      });
      return NextResponse.json({ success: true, message: 'Training paused' });
    }

    if (action === 'resume') {
      await prisma.federatedTrainingRun.update({
        where: { id: runId },
        data: { status: 'RUNNING' },
      });
      return NextResponse.json({ success: true, message: 'Training resumed' });
    }

    if (action === 'update') {
      const run = await prisma.federatedTrainingRun.update({
        where: { id: runId },
        data: {
          currentRound: round,
          globalModelAccuracy: accuracy,
          globalModelLoss: loss,
        },
      });

      return NextResponse.json({
        success: true,
        run: {
          currentRound: run.currentRound,
          accuracy: run.globalModelAccuracy,
          loss: run.globalModelLoss,
        },
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('Update FL run error:', error);
    return NextResponse.json(
      { error: 'Failed to update training run' },
      { status: 500 }
    );
  }
}
