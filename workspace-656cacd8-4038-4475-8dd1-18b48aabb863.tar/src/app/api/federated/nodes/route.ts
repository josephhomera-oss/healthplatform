import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const nodes = await db.federatedNode.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        trainingRounds: {
          orderBy: { createdAt: 'desc' },
          take: 5
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: nodes
    })
  } catch (error) {
    console.error('Get federated nodes error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch federated nodes' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { nodeName, hospitalName, ipAddress, port } = body

    if (!nodeName || !hospitalName || !ipAddress) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const node = await db.federatedNode.create({
      data: {
        nodeName,
        hospitalName,
        ipAddress,
        port: port || 8080,
        status: 'ACTIVE',
        totalContributions: 0
      }
    })

    return NextResponse.json({
      success: true,
      data: node,
      message: 'Federated node registered successfully'
    })
  } catch (error) {
    console.error('Create federated node error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create federated node' },
      { status: 500 }
    )
  }
}
