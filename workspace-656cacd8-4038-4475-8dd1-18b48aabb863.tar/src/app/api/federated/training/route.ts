import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const currentRound = searchParams.get('currentRound')

    // Get current training status
    const nodes = await db.federatedNode.findMany({
      where: { status: 'ACTIVE' }
    })

    const latestRound = await db.trainingRound.findFirst({
      orderBy: { roundNumber: 'desc' }
    })

    const roundMetrics = await db.trainingRound.findMany({
      where: { status: 'COMPLETED' },
      orderBy: { roundNumber: 'asc' },
      take: 20,
      select: {
        roundNumber: true,
        localAccuracy: true,
        localLoss: true,
        nodeId: true,
        createdAt: true
      }
    })

    // Calculate aggregate metrics
    const currentRoundNumber = latestRound ? latestRound.roundNumber + 1 : 1
    const totalRounds = 50 // Configurable

    return NextResponse.json({
      success: true,
      data: {
        currentRound: currentRoundNumber,
        totalRounds,
        participatingNodes: nodes.length,
        aggregationStatus: latestRound?.status === 'RUNNING' ? 'AGGREGATING' : 'WAITING',
        globalModelVersion: 'FL-RAD-2.1.0',
        roundMetrics: roundMetrics.map(r => ({
          round: r.roundNumber,
          accuracy: r.localAccuracy || 0,
          loss: r.localLoss || 0,
          participatingNodes: [r.nodeId],
          timestamp: r.createdAt
        }))
      }
    })
  } catch (error) {
    console.error('Get training status error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch training status' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action } = body

    if (action === 'start') {
      // Get active nodes
      const nodes = await db.federatedNode.findMany({
        where: { status: 'ACTIVE' }
      })

      if (nodes.length < 2) {
        return NextResponse.json(
          { success: false, error: 'At least 2 active nodes required' },
          { status: 400 }
        )
      }

      // Get latest round
      const latestRound = await db.trainingRound.findFirst({
        orderBy: { roundNumber: 'desc' }
      })

      const nextRound = (latestRound?.roundNumber || 0) + 1

      // Create training rounds for each node
      for (const node of nodes) {
        await db.trainingRound.create({
          data: {
            roundNumber: nextRound,
            nodeId: node.id,
            status: 'PENDING'
          }
        })

        // Update node status
        await db.federatedNode.update({
          where: { id: node.id },
          data: { status: 'SYNCING' }
        })
      }

      return NextResponse.json({
        success: true,
        message: `Training round ${nextRound} started`,
        data: {
          roundNumber: nextRound,
          participatingNodes: nodes.length
        }
      })
    }

    if (action === 'stop') {
      // Cancel running rounds
      await db.trainingRound.updateMany({
        where: { status: 'RUNNING' },
        data: { status: 'CANCELLED' }
      })

      // Reset node statuses
      await db.federatedNode.updateMany({
        where: { status: 'SYNCING' },
        data: { status: 'ACTIVE' }
      })

      return NextResponse.json({
        success: true,
        message: 'Training stopped'
      })
    }

    return NextResponse.json(
      { success: false, error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Training action error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to execute training action' },
      { status: 500 }
    )
  }
}
