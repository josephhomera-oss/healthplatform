import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { getUltrasoundGuidance } from '@/lib/ai-service';

// POST /api/ultrasound/guidance - Get real-time ultrasound guidance
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { sessionId, currentView, probePosition, probeOrientation, targetView } = data;

    // Get guidance from AI service
    const guidance = await getUltrasoundGuidance({
      currentView,
      probePosition: probePosition || { x: 0, y: 0, z: 0 },
      probeOrientation: probeOrientation || { roll: 0, pitch: 0, yaw: 0 },
      targetView: targetView || 'Apical 4-Chamber',
    });

    // Update session if exists
    if (sessionId) {
      await prisma.ultrasoundSession.update({
        where: { id: sessionId },
        data: {
          currentViewQuality: guidance.viewQuality,
          guidanceCommands: JSON.stringify(guidance.guidance),
        },
      }).catch(() => {
        // Session might not exist, continue anyway
      });
    }

    return NextResponse.json({
      success: true,
      guidance: {
        viewQuality: guidance.viewQuality,
        targetView: guidance.targetView,
        direction: guidance.guidance.direction,
        magnitude: guidance.guidance.magnitude,
        description: guidance.guidance.description,
        anatomicalLandmarks: guidance.anatomicalLandmarks,
        confidence: guidance.confidence,
      },
    });
  } catch (error) {
    console.error('Ultrasound guidance error:', error);
    return NextResponse.json(
      { error: 'Failed to generate guidance' },
      { status: 500 }
    );
  }
}

// POST /api/ultrasound/session - Start new ultrasound session
export async function PUT(request: NextRequest) {
  try {
    const data = await request.json();
    const { scanId, targetView } = data;

    const session = await prisma.ultrasoundSession.create({
      data: {
        scanId,
        viewTarget: targetView,
        currentViewQuality: 0,
        framesCaptured: 0,
      },
    });

    return NextResponse.json({
      success: true,
      session: {
        id: session.id,
        scanId: session.scanId,
        targetView: session.viewTarget,
        sessionStart: session.sessionStart,
      },
    });
  } catch (error) {
    console.error('Start session error:', error);
    return NextResponse.json(
      { error: 'Failed to start session' },
      { status: 500 }
    );
  }
}
