import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

// Ultrasound guidance templates
const PROBE_POSITIONS = [
  { optimal: 'Subcostal Long Axis', adjustment: 'Rotate probe 15° clockwise for better visualization' },
  { optimal: 'Intercostal Oblique', adjustment: 'Move probe one intercostal space superior' },
  { optimal: 'Parasternal Short Axis', adjustment: 'Tilt probe caudally for optimal view' },
  { optimal: 'Apical 4-Chamber', adjustment: 'Maintain current position, excellent view quality' },
  { optimal: 'Subxiphoid', adjustment: 'Apply more pressure for clearer image' },
]

const ANNOTATION_TYPES = [
  { type: 'arrow' as const, label: 'Chamber of interest', color: '#00FF00' },
  { type: 'circle' as const, label: 'Region of interest', color: '#FFD700' },
  { type: 'text' as const, label: 'Measurement point', color: '#00BFFF' },
  { type: 'region' as const, label: 'Abnormal area', color: '#FF6B6B' },
]

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sessionId, frameData, patientId } = body

    // Create or update ultrasound session
    let session
    if (sessionId) {
      session = await db.ultrasoundSession.findUnique({
        where: { id: sessionId }
      })
    }

    if (!session) {
      session = await db.ultrasoundSession.create({
        data: {
          patientId,
          sonographerId: 'user-sono-001',
          status: 'ACTIVE'
        }
      })
    }

    // Use AI to generate guidance
    let aiGuidance = ''
    try {
      const zai = await ZAI.create()
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert ultrasound imaging AI assistant providing real-time guidance. Give concise, actionable probe positioning and imaging advice.'
          },
          {
            role: 'user',
            content: 'Provide guidance for an ultrasound examination. Current view quality assessment and probe adjustment recommendations needed.'
          }
        ],
        temperature: 0.4,
        max_tokens: 200
      })
      aiGuidance = completion.choices[0]?.message?.content || ''
    } catch (aiError) {
      console.error('AI guidance error:', aiError)
    }

    // Simulate view quality (0-100)
    const viewQuality = 60 + Math.random() * 35

    // Select random probe position guidance
    const positionGuidance = PROBE_POSITIONS[Math.floor(Math.random() * PROBE_POSITIONS.length)]

    // Generate random annotations
    const annotations = []
    const numAnnotations = 1 + Math.floor(Math.random() * 3)
    for (let i = 0; i < numAnnotations; i++) {
      const annotationType = ANNOTATION_TYPES[Math.floor(Math.random() * ANNOTATION_TYPES.length)]
      annotations.push({
        type: annotationType.type,
        x: 50 + Math.random() * 200,
        y: 50 + Math.random() * 150,
        label: annotationType.label,
        color: annotationType.color
      })
    }

    // Generate recommendations based on quality
    const recommendations = []
    if (viewQuality < 70) {
      recommendations.push('Adjust probe angle for better visualization')
      recommendations.push('Consider patient positioning change')
    } else if (viewQuality >= 70 && viewQuality < 85) {
      recommendations.push('Good view quality - capture current frame')
      recommendations.push('Minor adjustments may improve clarity')
    } else {
      recommendations.push('Excellent view - capture recommended')
      recommendations.push('Ready for measurements')
    }

    if (aiGuidance) {
      recommendations.push(aiGuidance)
    }

    // Update session
    await db.ultrasoundSession.update({
      where: { id: session.id },
      data: {
        viewQuality,
        probePosition: positionGuidance.optimal,
        guidanceNotes: aiGuidance,
        capturedFrames: { increment: 1 }
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        sessionId: session.id,
        viewQuality,
        probePosition: {
          optimal: positionGuidance.optimal,
          current: 'Current Position',
          adjustment: positionGuidance.adjustment
        },
        annotations,
        recommendations,
        timestamp: new Date().toISOString()
      }
    })

  } catch (error) {
    console.error('Ultrasound stream error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to process ultrasound stream' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get('sessionId')

    if (sessionId) {
      const session = await db.ultrasoundSession.findUnique({
        where: { id: sessionId }
      })

      if (!session) {
        return NextResponse.json(
          { success: false, error: 'Session not found' },
          { status: 404 }
        )
      }

      return NextResponse.json({
        success: true,
        data: session
      })
    }

    // Return active sessions
    const sessions = await db.ultrasoundSession.findMany({
      where: { status: 'ACTIVE' },
      orderBy: { startedAt: 'desc' },
      take: 10
    })

    return NextResponse.json({
      success: true,
      data: sessions
    })
  } catch (error) {
    console.error('Get ultrasound sessions error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch ultrasound sessions' },
      { status: 500 }
    )
  }
}
