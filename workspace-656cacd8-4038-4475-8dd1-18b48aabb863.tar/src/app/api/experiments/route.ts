import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET /api/experiments - List all experiments
export async function GET(request: NextRequest) {
  try {
    const experiments = await prisma.experimentLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return NextResponse.json({
      experiments: experiments.map((e) => ({
        id: e.id,
        name: e.experimentName,
        type: e.experimentType,
        hyperparameters: JSON.parse(e.hyperparameters as string || '{}'),
        metrics: JSON.parse(e.metrics as string || '{}'),
        status: e.status,
        errorMessage: e.errorMessage,
        startedAt: e.startedAt,
        completedAt: e.completedAt,
        createdAt: e.createdAt,
      })),
    });
  } catch (error) {
    console.error('Get experiments error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch experiments' },
      { status: 500 }
    );
  }
}

// GET /api/models - List all models
export async function POST(request: NextRequest) {
  try {
    const models = await prisma.modelVersion.findMany({
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      models: models.map((m) => ({
        id: m.id,
        name: m.modelName,
        type: m.modelType,
        version: m.version,
        description: m.description,
        trainingMetrics: JSON.parse(m.trainingMetrics as string || '{}'),
        validationMetrics: JSON.parse(m.validationMetrics as string || '{}'),
        isDeployed: m.isDeployed,
        deployedAt: m.deployedAt,
        createdAt: m.createdAt,
      })),
    });
  } catch (error) {
    console.error('Get models error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch models' },
      { status: 500 }
    );
  }
}
