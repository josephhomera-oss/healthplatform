import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const models = await db.modelVersion.findMany({
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      data: models
    })
  } catch (error) {
    console.error('Get models error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch models' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { modelType, version, description, performance, accuracy, precision, recall, f1Score, auc } = body

    if (!modelType || !version || performance === undefined) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const model = await db.modelVersion.create({
      data: {
        modelType: modelType as 'RADIOLOGY' | 'ULTRASOUND' | 'CAUSAL' | 'FEDERATED',
        version,
        description,
        performance,
        accuracy,
        precision,
        recall,
        f1Score,
        auc,
        isDeployed: false
      }
    })

    return NextResponse.json({
      success: true,
      data: model,
      message: 'Model version created successfully'
    })
  } catch (error) {
    console.error('Create model error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create model version' },
      { status: 500 }
    )
  }
}
