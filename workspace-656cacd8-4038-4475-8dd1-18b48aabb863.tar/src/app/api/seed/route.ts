import { NextResponse } from 'next/server';
import prisma from '@/lib/db';
import bcrypt from 'bcryptjs';

export async function GET() {
  try {
    // Create demo users
    const hashedPassword = await bcrypt.hash('demo123', 10);
    
    const admin = await prisma.user.upsert({
      where: { email: 'admin@healthcare.ai' },
      update: {},
      create: {
        email: 'admin@healthcare.ai',
        name: 'Dr. Sarah Chen',
        password: hashedPassword,
        role: 'ADMIN',
        hospitalAffiliation: 'Medical Center Hospital',
      },
    });

    const radiologist = await prisma.user.upsert({
      where: { email: 'radiologist@healthcare.ai' },
      update: {},
      create: {
        email: 'radiologist@healthcare.ai',
        name: 'Dr. James Wilson',
        password: hashedPassword,
        role: 'RADIOLOGIST',
        hospitalAffiliation: 'Medical Center Hospital',
      },
    });

    const sonographer = await prisma.user.upsert({
      where: { email: 'sonographer@healthcare.ai' },
      update: {},
      create: {
        email: 'sonographer@healthcare.ai',
        name: 'Maria Rodriguez',
        password: hashedPassword,
        role: 'SONOGRAPHER',
        hospitalAffiliation: 'Medical Center Hospital',
      },
    });

    const researcher = await prisma.user.upsert({
      where: { email: 'researcher@healthcare.ai' },
      update: {},
      create: {
        email: 'researcher@healthcare.ai',
        name: 'Dr. Emily Park',
        password: hashedPassword,
        role: 'RESEARCHER',
        hospitalAffiliation: 'University Medical Center',
      },
    });

    // Create demo patients
    const patient1 = await prisma.patient.upsert({
      where: { medicalRecordNumber: 'MRN-2024-001' },
      update: {},
      create: {
        medicalRecordNumber: 'MRN-2024-001',
        firstName: 'John',
        lastName: 'Smith',
        dateOfBirth: new Date('1965-03-15'),
        gender: 'MALE',
        bloodType: 'A+',
        allergies: 'Penicillin',
      },
    });

    const patient2 = await prisma.patient.upsert({
      where: { medicalRecordNumber: 'MRN-2024-002' },
      update: {},
      create: {
        medicalRecordNumber: 'MRN-2024-002',
        firstName: 'Emma',
        lastName: 'Johnson',
        dateOfBirth: new Date('1978-07-22'),
        gender: 'FEMALE',
        bloodType: 'O+',
        allergies: null,
      },
    });

    const patient3 = await prisma.patient.upsert({
      where: { medicalRecordNumber: 'MRN-2024-003' },
      update: {},
      create: {
        medicalRecordNumber: 'MRN-2024-003',
        firstName: 'Michael',
        lastName: 'Williams',
        dateOfBirth: new Date('1952-11-08'),
        gender: 'MALE',
        bloodType: 'B+',
        allergies: 'Aspirin, Sulfa drugs',
      },
    });

    // Create demo scans
    const scan1 = await prisma.scan.create({
      data: {
        patientId: patient1.id,
        uploadedById: radiologist.id,
        scanType: 'CT',
        bodyPart: 'Chest',
        modalityDetails: 'CT Chest with Contrast',
        filePath: '/scans/ct-chest-001.dicom',
        fileSize: 125.4,
        dimensions: '512x512x320',
        status: 'COMPLETED',
        priority: 'ROUTINE',
        processedAt: new Date(),
      },
    });

    const scan2 = await prisma.scan.create({
      data: {
        patientId: patient2.id,
        uploadedById: radiologist.id,
        scanType: 'CT',
        bodyPart: 'Abdomen',
        modalityDetails: 'CT Abdomen/Pelvis with Contrast',
        filePath: '/scans/ct-abdomen-002.dicom',
        fileSize: 185.2,
        dimensions: '512x512x400',
        status: 'PROCESSING',
        priority: 'URGENT',
      },
    });

    const scan3 = await prisma.scan.create({
      data: {
        patientId: patient3.id,
        uploadedById: sonographer.id,
        scanType: 'ULTRASOUND',
        bodyPart: 'Cardiac',
        modalityDetails: 'Echocardiogram',
        filePath: '/scans/echo-003.dicom',
        fileSize: 45.8,
        dimensions: '640x480x1',
        status: 'COMPLETED',
        priority: 'STAT',
        processedAt: new Date(),
      },
    });

    // Create analysis results
    await prisma.analysisResult.create({
      data: {
        scanId: scan1.id,
        findings: JSON.stringify([
          { type: 'Nodule', location: 'Right Upper Lobe', severity: 'Moderate', description: '8mm nodule, indeterminate' },
          { type: 'Calcification', location: 'Left Lower Lobe', severity: 'Benign', description: 'Calcified granuloma' },
        ]),
        primaryDiagnosis: 'Pulmonary Nodule - Indeterminate',
        diagnosisCode: 'R91.1',
        confidence: 0.87,
        heatmapPath: '/heatmaps/ct-chest-001-heatmap.png',
        sensitivity: 0.92,
        specificity: 0.88,
        nodulesDetected: 1,
        noduleDetails: JSON.stringify([
          { id: 'N1', size: 8.2, location: 'RUL Segment 3', malignancyRisk: 0.35 },
        ]),
        imageQualityScore: 0.94,
        processingTimeMs: 2340,
        modelVersion: 'v2.1.0-federated',
      },
    });

    await prisma.analysisResult.create({
      data: {
        scanId: scan3.id,
        findings: JSON.stringify([
          { type: 'Ejection Fraction', location: 'Left Ventricle', severity: 'Normal', description: 'LVEF 62%' },
          { type: 'Valvular Function', location: 'All Valves', severity: 'Normal', description: 'No significant regurgitation' },
        ]),
        primaryDiagnosis: 'Normal Echocardiogram',
        confidence: 0.95,
        imageQualityScore: 0.89,
        processingTimeMs: 1850,
        modelVersion: 'v1.8.0-ultrasound',
      },
    });

    // Create federated learning nodes
    await prisma.federatedNode.createMany({
      data: [
        {
          nodeName: 'Node-MCH-01',
          hospitalName: 'Medical Center Hospital',
          ipAddress: '10.0.1.100',
          status: 'ACTIVE',
          localDataSize: 15234,
          trainingRoundsCompleted: 45,
        },
        {
          nodeName: 'Node-UMC-01',
          hospitalName: 'University Medical Center',
          ipAddress: '10.0.2.100',
          status: 'ACTIVE',
          localDataSize: 23456,
          trainingRoundsCompleted: 45,
        },
        {
          nodeName: 'Node-RGH-01',
          hospitalName: 'Regional General Hospital',
          ipAddress: '10.0.3.100',
          status: 'TRAINING',
          localDataSize: 8901,
          trainingRoundsCompleted: 44,
        },
        {
          nodeName: 'Node-CMH-01',
          hospitalName: 'City Metropolitan Hospital',
          ipAddress: '10.0.4.100',
          status: 'ACTIVE',
          localDataSize: 31245,
          trainingRoundsCompleted: 45,
        },
        {
          nodeName: 'Node-SMC-01',
          hospitalName: 'St. Marys Clinic',
          ipAddress: '10.0.5.100',
          status: 'INACTIVE',
          localDataSize: 4523,
          trainingRoundsCompleted: 42,
        },
      ],
      skipDuplicates: true,
    });

    // Create model versions
    await prisma.modelVersion.createMany({
      data: [
        {
          modelName: 'Radiology Foundation Model',
          modelType: 'RADIOLOGY_FOUNDATION',
          version: 'v2.1.0',
          description: 'Federated pre-trained model for CT scan analysis',
          modelPath: '/models/radiology-foundation-v2.1.0.pth',
          trainingMetrics: JSON.stringify({ epochs: 100, finalLoss: 0.08 }),
          validationMetrics: JSON.stringify({ auc: 0.94, sensitivity: 0.92, specificity: 0.89 }),
          isDeployed: true,
          deployedAt: new Date(),
        },
        {
          modelName: 'Ultrasound Co-Pilot',
          modelType: 'ULTRASOUND_COPILOT',
          version: 'v1.8.0',
          description: 'DRL agent for ultrasound guidance with PINN integration',
          modelPath: '/models/ultrasound-copilot-v1.8.0.pth',
          trainingMetrics: JSON.stringify({ episodes: 50000, successRate: 0.89 }),
          validationMetrics: JSON.stringify({ timeToAcquisition: 12.5, successRate: 0.91 }),
          isDeployed: true,
          deployedAt: new Date(),
        },
        {
          modelName: 'Causal Transformer',
          modelType: 'CAUSAL_TRANSFORMER',
          version: 'v1.2.0',
          description: 'Causal inference model for treatment effect estimation',
          modelPath: '/models/causal-transformer-v1.2.0.pth',
          trainingMetrics: JSON.stringify({ samples: 8500, pehe: 0.24 }),
          validationMetrics: JSON.stringify({ ateError: 0.08, coverage: 0.93 }),
          isDeployed: true,
          deployedAt: new Date(),
        },
      ],
      skipDuplicates: true,
    });

    // Create experiment logs
    await prisma.experimentLog.createMany({
      data: [
        {
          experimentName: 'FL-Round-45-Radiology',
          experimentType: 'TRAINING',
          hyperparameters: JSON.stringify({ lr: 0.001, batchSize: 32, rounds: 100 }),
          metrics: JSON.stringify({ accuracy: 0.892, loss: 0.145, auc: 0.921 }),
          status: 'COMPLETED',
          completedAt: new Date(),
        },
        {
          experimentName: 'Ultrasound-DRL-Training',
          experimentType: 'TRAINING',
          hyperparameters: JSON.stringify({ gamma: 0.99, epsilon: 0.1, episodes: 50000 }),
          metrics: JSON.stringify({ successRate: 0.89, avgTimeToAcquisition: 12.5 }),
          status: 'COMPLETED',
          completedAt: new Date(),
        },
        {
          experimentName: 'Causal-Model-Eval',
          experimentType: 'EVALUATION',
          hyperparameters: JSON.stringify({ confounders: ['age', 'tumor_size', 'prior_treatment'] }),
          metrics: JSON.stringify({ pehe: 0.24, ateBias: 0.08 }),
          status: 'COMPLETED',
          completedAt: new Date(),
        },
      ],
      skipDuplicates: true,
    });

    // Create causal reports
    await prisma.causalReport.create({
      data: {
        patientId: patient1.id,
        generatedById: researcher.id,
        treatmentType: 'Immunotherapy',
        treatmentProtocol: 'Pembrolizumab 200mg q3weeks',
        individualTreatmentEffect: 0.42,
        averageTreatmentEffect: 0.35,
        confidenceIntervalLower: 0.28,
        confidenceIntervalUpper: 0.56,
        actualOutcome: 'Partial Response - 35% tumor reduction at 12 weeks',
        counterfactualOutcome: 'Without treatment: predicted 23% tumor progression',
        causalFactors: JSON.stringify([
          { factor: 'Tumor PD-L1 Expression', contribution: 0.35, direction: 'positive' },
          { factor: 'Baseline Tumor Burden', contribution: 0.25, direction: 'negative' },
          { factor: 'Patient Age', contribution: 0.15, direction: 'negative' },
        ]),
        status: 'COMPLETED',
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        users: 4,
        patients: 3,
        scans: 3,
        nodes: 5,
        models: 3,
        experiments: 3,
      },
    });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json(
      { error: 'Failed to seed database', details: String(error) },
      { status: 500 }
    );
  }
}
