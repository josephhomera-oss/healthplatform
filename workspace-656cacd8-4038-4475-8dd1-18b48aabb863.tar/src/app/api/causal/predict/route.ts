import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { predictTreatmentResponse } from '@/lib/ai-service';

// POST /api/causal/predict - Generate causal treatment prediction
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { patientId, treatmentType, baselineMetrics, longitudinalData, confounders, generatedById } = data;

    // Get patient info
    const patient = await prisma.patient.findUnique({
      where: { id: patientId },
    });

    if (!patient) {
      return NextResponse.json({ error: 'Patient not found' }, { status: 404 });
    }

    // Perform causal analysis
    const causalResult = await predictTreatmentResponse({
      patientId,
      treatmentType,
      baselineMetrics: baselineMetrics || { tumorSize: 45, metabolicActivity: 8.2 },
      longitudinalData: longitudinalData || [],
      confounders: confounders || ['age', 'tumor_size', 'prior_treatment'],
    });

    // Create causal report
    const report = await prisma.causalReport.create({
      data: {
        patientId,
        generatedById: generatedById || 'demo-user',
        treatmentType,
        structuralCausalModel: 'SCM-Oncology-v1',
        individualTreatmentEffect: causalResult.individualTreatmentEffect,
        confidenceIntervalLower: causalResult.confidenceInterval[0],
        confidenceIntervalUpper: causalResult.confidenceInterval[1],
        actualOutcome: causalResult.actualOutcome,
        counterfactualOutcome: causalResult.counterfactualOutcome,
        causalFactors: JSON.stringify(causalResult.causalFactors),
        recommendations: JSON.stringify(causalResult.recommendations),
        status: 'COMPLETED',
      },
    });

    return NextResponse.json({
      success: true,
      report: {
        id: report.id,
        patientId: report.patientId,
        treatmentType: report.treatmentType,
        individualTreatmentEffect: report.individualTreatmentEffect,
        confidenceInterval: [report.confidenceIntervalLower, report.confidenceIntervalUpper],
        actualOutcome: report.actualOutcome,
        counterfactualOutcome: report.counterfactualOutcome,
        causalFactors: causalResult.causalFactors,
        recommendations: causalResult.recommendations,
        createdAt: report.createdAt,
      },
    });
  } catch (error) {
    console.error('Causal prediction error:', error);
    return NextResponse.json(
      { error: 'Failed to generate causal prediction' },
      { status: 500 }
    );
  }
}

// GET /api/causal/predict?patientId=xxx - Get causal reports for patient
export async function GET(request: NextRequest) {
  try {
    const patientId = request.nextUrl.searchParams.get('patientId');
    const reportId = request.nextUrl.searchParams.get('reportId');

    if (reportId) {
      const report = await prisma.causalReport.findUnique({
        where: { id: reportId },
        include: { patient: true },
      });

      if (!report) {
        return NextResponse.json({ error: 'Report not found' }, { status: 404 });
      }

      return NextResponse.json({
        report: {
          id: report.id,
          patient: {
            name: `${report.patient.firstName} ${report.patient.lastName}`,
            mrn: report.patient.medicalRecordNumber,
          },
          treatmentType: report.treatmentType,
          treatmentProtocol: report.treatmentProtocol,
          individualTreatmentEffect: report.individualTreatmentEffect,
          confidenceInterval: [report.confidenceIntervalLower, report.confidenceIntervalUpper],
          actualOutcome: report.actualOutcome,
          counterfactualOutcome: report.counterfactualOutcome,
          causalFactors: JSON.parse(report.causalFactors as string || '[]'),
          recommendations: JSON.parse(report.recommendations as string || '[]'),
          status: report.status,
          createdAt: report.createdAt,
        },
      });
    }

    const where = patientId ? { patientId } : {};
    const reports = await prisma.causalReport.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: { patient: true },
    });

    return NextResponse.json({
      reports: reports.map((r) => ({
        id: r.id,
        patient: {
          id: r.patient.id,
          name: `${r.patient.firstName} ${r.patient.lastName}`,
          mrn: r.patient.medicalRecordNumber,
        },
        treatmentType: r.treatmentType,
        individualTreatmentEffect: r.individualTreatmentEffect,
        status: r.status,
        createdAt: r.createdAt,
      })),
    });
  } catch (error) {
    console.error('Get causal reports error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reports' },
      { status: 500 }
    );
  }
}
