import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET /api/scans - List all scans
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const scanType = searchParams.get('scanType');
    const patientId = searchParams.get('patientId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (scanType) where.scanType = scanType;
    if (patientId) where.patientId = patientId;

    const [scans, total] = await Promise.all([
      prisma.scan.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          patient: true,
          analysisResult: true,
        },
      }),
      prisma.scan.count({ where }),
    ]);

    return NextResponse.json({
      scans: scans.map((s) => ({
        id: s.id,
        patient: {
          id: s.patient.id,
          name: `${s.patient.firstName} ${s.patient.lastName}`,
          mrn: s.patient.medicalRecordNumber,
        },
        scanType: s.scanType,
        bodyPart: s.bodyPart,
        modalityDetails: s.modalityDetails,
        fileSize: s.fileSize,
        dimensions: s.dimensions,
        status: s.status,
        priority: s.priority,
        diagnosis: s.analysisResult?.primaryDiagnosis,
        confidence: s.analysisResult?.confidence,
        processedAt: s.processedAt,
        createdAt: s.createdAt,
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get scans error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch scans' },
      { status: 500 }
    );
  }
}

// POST /api/scans - Create new scan
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const scan = await prisma.scan.create({
      data: {
        patientId: data.patientId,
        uploadedById: data.uploadedById || 'demo-user',
        scanType: data.scanType,
        bodyPart: data.bodyPart,
        modalityDetails: data.modalityDetails,
        filePath: data.filePath || '/scans/pending',
        fileSize: data.fileSize,
        dimensions: data.dimensions,
        priority: data.priority || 'ROUTINE',
      },
      include: {
        patient: true,
      },
    });

    return NextResponse.json(scan, { status: 201 });
  } catch (error) {
    console.error('Create scan error:', error);
    return NextResponse.json(
      { error: 'Failed to create scan' },
      { status: 500 }
    );
  }
}
