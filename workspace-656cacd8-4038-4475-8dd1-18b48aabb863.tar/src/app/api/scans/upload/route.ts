import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    
    const patientId = formData.get('patientId') as string
    const scanType = formData.get('scanType') as string
    const bodyPart = formData.get('bodyPart') as string
    const description = formData.get('description') as string
    const priority = formData.get('priority') as string || 'NORMAL'
    const uploadedBy = formData.get('uploadedBy') as string || 'user-admin-001'
    const file = formData.get('file') as File | null

    if (!patientId || !scanType || !bodyPart) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Create uploads directory if it doesn't exist
    const uploadDir = path.join(process.cwd(), 'uploads', 'scans')
    await mkdir(uploadDir, { recursive: true })

    let filePath = ''
    let fileSize = 0

    if (file) {
      const bytes = await file.arrayBuffer()
      const buffer = Buffer.from(bytes)
      
      const fileName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`
      filePath = path.join(uploadDir, fileName)
      fileSize = file.size
      
      await writeFile(filePath, buffer)
      filePath = `/uploads/scans/${fileName}`
    } else {
      // Use placeholder for demo
      filePath = `/demo/scan-${scanType.toLowerCase()}-${bodyPart.toLowerCase()}.dcm`
    }

    const scan = await db.scan.create({
      data: {
        patientId,
        scanType: scanType as 'CT' | 'ULTRASOUND' | 'MRI' | 'XRAY' | 'PET',
        bodyPart,
        description,
        priority: priority as 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT',
        uploadedBy,
        filePath,
        fileSize,
        status: 'PENDING'
      },
      include: {
        patient: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            medicalRecordNumber: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: scan,
      message: 'Scan uploaded successfully'
    })
  } catch (error) {
    console.error('Upload scan error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to upload scan' },
      { status: 500 }
    )
  }
}
