import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const scan = await db.scan.findUnique({
      where: { id },
      include: {
        patient: true,
        analysisResults: {
          orderBy: { createdAt: 'desc' }
        }
      }
    })

    if (!scan) {
      return NextResponse.json(
        { success: false, error: 'Scan not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: scan
    })
  } catch (error) {
    console.error('Get scan error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch scan' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    const scan = await db.scan.update({
      where: { id },
      data: body
    })

    return NextResponse.json({
      success: true,
      data: scan,
      message: 'Scan updated successfully'
    })
  } catch (error) {
    console.error('Update scan error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update scan' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    await db.scan.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Scan deleted successfully'
    })
  } catch (error) {
    console.error('Delete scan error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to delete scan' },
      { status: 500 }
    )
  }
}
