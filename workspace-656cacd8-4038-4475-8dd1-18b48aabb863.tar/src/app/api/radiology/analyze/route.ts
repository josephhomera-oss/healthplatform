import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { analyzeCTScan } from '@/lib/ai-service';

// POST /api/radiology/analyze - Analyze a CT scan
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { scanId } = data;

    // Get scan details
    const scan = await prisma.scan.findUnique({
      where: { id: scanId },
      include: { patient: true },
    });

    if (!scan) {
      return NextResponse.json({ error: 'Scan not found' }, { status: 404 });
    }

    // Update scan status to processing
    await prisma.scan.update({
      where: { id: scanId },
      data: { status: 'PROCESSING' },
    });

    // Perform AI analysis
    const startTime = Date.now();
    const analysisResult = await analyzeCTScan('base64-image-data', {
      bodyPart: scan.bodyPart,
      modality: scan.modalityDetails || scan.scanType,
      patientAge: scan.patient.dateOfBirth
        ? Math.floor((Date.now() - new Date(scan.patient.dateOfBirth).getTime()) / (365.25 * 24 * 60 * 60 * 1000))
        : undefined,
      patientGender: scan.patient.gender,
    });
    const processingTime = Date.now() - startTime;

    // Save analysis result
    const result = await prisma.analysisResult.create({
      data: {
        scanId,
        findings: JSON.stringify(analysisResult.findings),
        primaryDiagnosis: analysisResult.diagnosis,
        confidence: analysisResult.confidence,
        heatmapPath: `/heatmaps/${scanId}-heatmap.png`,
        nodulesDetected: analysisResult.nodules.length,
        noduleDetails: JSON.stringify(analysisResult.nodules),
        sensitivity: 0.92,
        specificity: 0.88,
        imageQualityScore: 0.94,
        processingTimeMs: processingTime,
        modelVersion: 'v2.1.0-federated',
      },
    });

    // Update scan status to completed
    await prisma.scan.update({
      where: { id: scanId },
      data: {
        status: 'COMPLETED',
        processedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      result: {
        id: result.id,
        diagnosis: result.primaryDiagnosis,
        confidence: result.confidence,
        findings: analysisResult.findings,
        nodules: analysisResult.nodules,
        recommendations: analysisResult.recommendations,
        processingTimeMs: processingTime,
      },
    });
  } catch (error) {
    console.error('Radiology analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze scan' },
      { status: 500 }
    );
  }
}

// GET /api/radiology/analyze?scanId=xxx - Get analysis result
export async function GET(request: NextRequest) {
  try {
    const scanId = request.nextUrl.searchParams.get('scanId');
    
    if (!scanId) {
      return NextResponse.json({ error: 'scanId required' }, { status: 400 });
    }

    const result = await prisma.analysisResult.findUnique({
      where: { scanId },
      include: {
        scan: {
          include: { patient: true },
        },
      },
    });

    if (!result) {
      return NextResponse.json({ error: 'Result not found' }, { status: 404 });
    }

    return NextResponse.json({
      id: result.id,
      scan: {
        id: result.scan.id,
        type: result.scan.scanType,
        bodyPart: result.scan.bodyPart,
      },
      patient: {
        name: `${result.scan.patient.firstName} ${result.scan.patient.lastName}`,
        mrn: result.scan.patient.medicalRecordNumber,
      },
      diagnosis: result.primaryDiagnosis,
      confidence: result.confidence,
      findings: JSON.parse(result.findings as string || '[]'),
      nodulesDetected: result.nodulesDetected,
      noduleDetails: JSON.parse(result.noduleDetails as string || '[]'),
      sensitivity: result.sensitivity,
      specificity: result.specificity,
      heatmapPath: result.heatmapPath,
      processingTimeMs: result.processingTimeMs,
      modelVersion: result.modelVersion,
      createdAt: result.createdAt,
    });
  } catch (error) {
    console.error('Get analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch analysis' },
      { status: 500 }
    );
  }
}
