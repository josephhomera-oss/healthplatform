'use client';

import { useState, useEffect, useCallback } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Sidebar } from '@/components/sidebar';
import { Dashboard } from '@/components/dashboard';
import { RadiologyModule } from '@/components/radiology-module';
import { UltrasoundModule } from '@/components/ultrasound-module';
import { CausalModule } from '@/components/causal-module';
import { FederatedModule } from '@/components/federated-module';
import { ExperimentsModule } from '@/components/experiments-module';
import { AdminModule } from '@/components/admin-module';
import { Toaster } from '@/components/ui/sonner';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,
      refetchOnWindowFocus: false,
    },
  },
});

export default function Home() {
  const [activeModule, setActiveModule] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isSeeded, setIsSeeded] = useState(false);

  // Seed database on first load
  useEffect(() => {
    const seedDatabase = async () => {
      try {
        const response = await fetch('/api/seed');
        const data = await response.json();
        if (data.success) {
          setIsSeeded(true);
          console.log('Database seeded:', data.data);
        }
      } catch (error) {
        console.error('Seed error:', error);
        setIsSeeded(true); // Continue anyway
      }
    };
    seedDatabase();
  }, []);

  const renderModule = useCallback(() => {
    switch (activeModule) {
      case 'dashboard':
        return <Dashboard />;
      case 'radiology':
        return <RadiologyModule />;
      case 'ultrasound':
        return <UltrasoundModule />;
      case 'causal':
        return <CausalModule />;
      case 'federated':
        return <FederatedModule />;
      case 'experiments':
        return <ExperimentsModule />;
      case 'admin':
        return <AdminModule />;
      default:
        return <Dashboard />;
    }
  }, [activeModule]);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex h-screen bg-slate-50 dark:bg-slate-900">
        <Sidebar
          activeModule={activeModule}
          setActiveModule={setActiveModule}
          isOpen={sidebarOpen}
          toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />
        <main className={`flex-1 overflow-auto transition-all duration-300 ${sidebarOpen ? 'ml-0' : 'ml-0'}`}>
          {!isSeeded ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-slate-600 dark:text-slate-400">Initializing Healthcare AI System...</p>
              </div>
            </div>
          ) : (
            renderModule()
          )}
        </main>
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}
