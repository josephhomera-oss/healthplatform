import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "HealthAI Diagnostics - AI-Powered Medical Imaging Platform",
  description: "Advanced Healthcare Diagnostics System with AI applications in medical imaging. Features federated learning, real-time ultrasound guidance, and causal treatment prediction.",
  keywords: ["Healthcare AI", "Medical Imaging", "Federated Learning", "Radiology AI", "Ultrasound", "Causal AI", "Diagnostics"],
  authors: [{ name: "HealthAI Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "HealthAI Diagnostics",
    description: "AI-Powered Medical Imaging Diagnostics Platform",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
